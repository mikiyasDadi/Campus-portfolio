# Goba Wereda Management System

A comprehensive JavaFX-based management system for Goba Wereda, Ethiopia, featuring advanced evaluation and reporting capabilities.

## 🎯 Enhanced Evaluation & Reporting System

### System Requirements Implemented:

#### 1. **Daily Evaluations** 📅
- **Comprehensive Daily Tracking**: Track work done each day with detailed performance metrics
- **Multi-Dimensional Scoring**: 
  - Productivity Score (0-5 scale)
  - Quality Score (0-5 scale)
  - Attendance Score (0-5 scale)
  - Teamwork Score (0-5 scale)
  - Automatic Overall Score Calculation
- **Detailed Work Documentation**:
  - Work completed description
  - Challenges faced
  - Improvement suggestions
  - Additional comments
- **Status Management**: Pending → Completed → Reviewed
- **Locking Mechanism**: Prevent editing/deletion after submission

#### 2. **Weekly Reports** 📊
- **7-Day Aggregation**: Summarize daily work for the week
- **Performance Analytics**: Average scores across all dimensions
- **Top Performers**: Identify best performing workers
- **Trend Analysis**: Performance patterns over the week
- **Recommendations**: Actionable insights for improvement

#### 3. **Monthly Reports** 📈
- **30-Day Summary**: Aggregate weekly data into monthly insights
- **Comprehensive Statistics**: 
  - Total workers evaluated
  - Total evaluations conducted
  - Average performance metrics
  - Performance distribution analysis
- **Strategic Insights**: Long-term performance trends

#### 4. **Quarterly Reports** 📋
- **3-Month Analysis**: Summarize 3 months of data (4 quarters per year)
- **Quarterly Performance Review**: 
  - Performance trends over the quarter
  - Seasonal patterns identification
  - Strategic planning insights
- **Comparative Analysis**: Quarter-over-quarter performance

#### 5. **Annual Reports** 📊
- **Complete 12-Month Summary**: Full year performance overview
- **Annual Performance Review**: 
  - Year-over-year comparisons
  - Long-term trend analysis
  - Strategic recommendations
- **Comprehensive Analytics**: Complete organizational performance picture

### 🔐 Access Limitation & Security Features

#### **Role-Based Access Control**:
- **Admin Role**: Full access to all features
  - Create, read, update, delete evaluations
  - Generate and export all report types
  - Lock/unlock evaluations and reports
  - Manage user permissions

- **Manager Role**: Limited administrative access
  - Create, read, update evaluations (no delete)
  - Generate and export reports
  - Lock evaluations (no unlock)
  - View performance analytics

- **Regular User Role**: Read-only access
  - View evaluations and reports
  - Export data (read-only)
  - No modification permissions

#### **Data Protection Features**:
- **Evaluation Locking**: Once submitted, evaluations cannot be edited/deleted
- **Report Locking**: Finalized reports are protected from modification
- **Permission Validation**: All operations check user permissions
- **Audit Trail**: Track who created/modified records

### 📤 Export Functionality

#### **Desktop Export Features**:
- **CSV Format**: All reports export to desktop in CSV format
- **Comprehensive Data**: Include all evaluation details and analytics
- **Professional Formatting**: 
  - Headers with system information
  - Summary statistics
  - Detailed evaluation data
  - Recommendations and insights
- **Automatic Naming**: Timestamped files for easy organization
- **Multiple Export Types**:
  - Individual evaluation exports
  - Aggregated report exports
  - Custom date range exports

### 🏗️ Technical Architecture

#### **Database Schema**:
```sql
-- Daily Evaluation Table
CREATE TABLE daily_evaluation (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    worker_id INTEGER NOT NULL,
    evaluation_date TEXT NOT NULL,
    evaluator TEXT NOT NULL,
    productivity_score REAL NOT NULL,
    quality_score REAL NOT NULL,
    attendance_score REAL NOT NULL,
    teamwork_score REAL NOT NULL,
    overall_score REAL NOT NULL,
    work_completed TEXT,
    challenges TEXT,
    improvements TEXT,
    comments TEXT,
    status TEXT DEFAULT 'Pending',
    is_locked INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Report Table
CREATE TABLE report (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_type TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    generated_by TEXT NOT NULL,
    generated_date TEXT NOT NULL,
    status TEXT DEFAULT 'Draft',
    is_locked INTEGER DEFAULT 0,
    total_workers INTEGER DEFAULT 0,
    total_evaluations INTEGER DEFAULT 0,
    average_overall_score REAL DEFAULT 0.0,
    -- ... additional metrics
);

-- User Permissions Table
CREATE TABLE user_permissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    permission_type TEXT NOT NULL,
    can_create INTEGER DEFAULT 0,
    can_read INTEGER DEFAULT 1,
    can_update INTEGER DEFAULT 0,
    can_delete INTEGER DEFAULT 0,
    can_export INTEGER DEFAULT 0,
    can_generate_reports INTEGER DEFAULT 0
);
```

#### **Key Components**:

1. **Models**:
   - `DailyEvaluation`: Comprehensive daily evaluation data
   - `Report`: Aggregated report data with analytics
   - `User`: User authentication and role management

2. **Controllers**:
   - `DailyEvaluationController`: Daily evaluation management
   - `ReportsController`: Enhanced reporting with new features
   - `DashboardController`: Main navigation and overview

3. **DAOs**:
   - `DailyEvaluationDAO`: Database operations for evaluations
   - `ReportDAO`: Report generation and management
   - `UserPermissionsDAO`: Access control management

4. **Utilities**:
   - `ReportGenerator`: Comprehensive report generation service
   - `DatabaseHelper`: Database schema management

### 🚀 Getting Started

#### **Prerequisites**:
- Java 11 or higher
- JavaFX SDK
- SQLite (included)

#### **Installation**:
1. Clone the repository
2. Ensure JavaFX is properly configured
3. Run `mvn clean install`
4. Execute `Main.java`

#### **Default Login**:
- Username: `admin`
- Password: `admin`
- Role: Administrator (full access)

### 📋 Usage Guide

#### **Daily Evaluation Workflow**:
1. Navigate to "Daily Evaluation" module
2. Select worker from dropdown
3. Set evaluation date
4. Enter evaluator name
5. Use sliders to set performance scores (0-5)
6. Fill in work details, challenges, improvements
7. Set status (Pending/Completed/Reviewed)
8. Save evaluation
9. Optionally lock evaluation to prevent changes

#### **Report Generation**:
1. Navigate to "Reports" module
2. Select report type (Weekly/Monthly/Quarterly/Annual)
3. Set date range
4. Click "Generate Report"
5. Review summary statistics and recommendations
6. Export to desktop if needed
7. Optionally lock report for finalization

#### **Access Control**:
- System automatically enforces permissions based on user role
- Locked evaluations/reports cannot be modified
- Export functionality respects user permissions
- All operations are logged for audit purposes

### 🔧 Configuration

#### **Database Setup**:
- SQLite database is automatically created on first run
- All tables are created with proper relationships
- Default admin user is created automatically
- Permission system is initialized

#### **Export Configuration**:
- Reports export to user's desktop directory
- CSV format with comprehensive formatting
- Automatic timestamping for file organization
- Configurable export paths

### 📊 Report Types & Features

#### **Daily Evaluations Report**:
- Individual evaluation records
- Performance scores breakdown
- Work completion details
- Status and locking information

#### **Weekly Report**:
- 7-day performance summary
- Average scores across dimensions
- Top performers identification
- Weekly trends and recommendations

#### **Monthly Report**:
- 30-day comprehensive analysis
- Performance distribution
- Strategic insights
- Monthly comparisons

#### **Quarterly Report**:
- 3-month aggregated data
- Seasonal pattern analysis
- Quarter-over-quarter comparisons
- Strategic planning insights

#### **Annual Report**:
- Complete year overview
- Long-term trend analysis
- Year-over-year comparisons
- Comprehensive organizational insights

### 🛡️ Security Features

#### **Data Protection**:
- Role-based access control
- Evaluation and report locking
- Permission validation on all operations
- Secure data export

#### **Audit Trail**:
- User action logging
- Modification tracking
- Access history
- Security event monitoring

### 🔄 Future Enhancements

#### **Planned Features**:
- PDF report generation
- Email report distribution
- Advanced analytics dashboard
- Mobile application support
- Real-time notifications
- Performance benchmarking
- Goal setting and tracking
- Automated report scheduling

### 📞 Support

For technical support or feature requests, please contact the development team.

---

**Goba Wereda Management System** - Empowering organizational management for Goba Wereda, Ethiopia. 