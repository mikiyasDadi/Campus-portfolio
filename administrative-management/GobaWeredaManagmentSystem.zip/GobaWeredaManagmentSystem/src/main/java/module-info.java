module com.example.gobaweredamanagmentsystem {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires java.sql;

    opens com.example.gobaweredamanagmentsystem to javafx.fxml;
    opens com.example.gobaweredamanagmentsystem.controllers to javafx.fxml;  // ADD THIS LINE

    exports com.example.gobaweredamanagmentsystem;
    exports com.example.gobaweredamanagmentsystem.controllers;
    exports com.example.gobaweredamanagmentsystem.utils;
    exports com.example.gobaweredamanagmentsystem.dao;
    exports com.example.gobaweredamanagmentsystem.models;
}