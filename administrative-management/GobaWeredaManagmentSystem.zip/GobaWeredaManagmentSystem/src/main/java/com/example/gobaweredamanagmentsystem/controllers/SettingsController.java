package com.example.gobaweredamanagmentsystem.controllers;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
public class SettingsController {

    @FXML private ComboBox<String> languageComboBox;
    @FXML private ComboBox<String> themeComboBox;
    @FXML private TextField orgNameField;
    @FXML private TextField orgDescField;
    @FXML private Text statusText;

    // You can use a Settings model or properties file for real persistence
    private String savedLanguage = "English";
    private String savedTheme = "Light";
    private String savedOrgName = "Goba Wereda";
    private String savedOrgDesc = "Empowering organizational management for Goba Wereda, Ethiopia.";

    @FXML
    public void initialize() {
        languageComboBox.setItems(FXCollections.observableArrayList("English", "Afan Oromo"));
        themeComboBox.setItems(FXCollections.observableArrayList("Light", "Dark"));

        // Load saved settings (stubbed for now)
        orgNameField.setText(savedOrgName);
        orgDescField.setText(savedOrgDesc);
        languageComboBox.setValue(savedLanguage);
        themeComboBox.setValue(savedTheme);

        statusText.setText(""); // Clear status on load
    }

    @FXML
    private void handleSave() {
        // Save settings (stubbed for now)
        savedLanguage = languageComboBox.getValue();
        savedTheme = themeComboBox.getValue();
        savedOrgName = orgNameField.getText();
        savedOrgDesc = orgDescField.getText();

        statusText.setText("Settings saved!");
        // TODO: Persist these settings to a file or database
    }
}