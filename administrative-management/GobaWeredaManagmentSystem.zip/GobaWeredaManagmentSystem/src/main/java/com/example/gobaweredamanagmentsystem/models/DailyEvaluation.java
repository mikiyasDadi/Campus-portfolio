package com.example.gobaweredamanagmentsystem.models;

import java.time.LocalDate;

public class DailyEvaluation {
    private int id;
    private int workerId;
    private String workerName;
    private LocalDate evaluationDate;
    private String evaluator;
    private double productivityScore;
    private double qualityScore;
    private double attendanceScore;
    private double teamworkScore;
    private double overallScore;
    private String workCompleted;
    private String challenges;
    private String improvements;
    private String comments;
    private String status; // "Pending", "Completed", "Reviewed"
    private boolean isLocked; // Prevents editing after submission

    public DailyEvaluation() {}

    public DailyEvaluation(int workerId, LocalDate evaluationDate, String evaluator, 
                          double productivityScore, double qualityScore, double attendanceScore, 
                          double teamworkScore, String workCompleted, String challenges, 
                          String improvements, String comments) {
        this.workerId = workerId;
        this.evaluationDate = evaluationDate;
        this.evaluator = evaluator;
        this.productivityScore = productivityScore;
        this.qualityScore = qualityScore;
        this.attendanceScore = attendanceScore;
        this.teamworkScore = teamworkScore;
        this.workCompleted = workCompleted;
        this.challenges = challenges;
        this.improvements = improvements;
        this.comments = comments;
        this.status = "Pending";
        this.isLocked = false;
        calculateOverallScore();
    }

    private void calculateOverallScore() {
        this.overallScore = (productivityScore + qualityScore + attendanceScore + teamworkScore) / 4.0;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getWorkerId() { return workerId; }
    public void setWorkerId(int workerId) { this.workerId = workerId; }

    public String getWorkerName() { return workerName; }
    public void setWorkerName(String workerName) { this.workerName = workerName; }

    public LocalDate getEvaluationDate() { return evaluationDate; }
    public void setEvaluationDate(LocalDate evaluationDate) { this.evaluationDate = evaluationDate; }

    public String getEvaluator() { return evaluator; }
    public void setEvaluator(String evaluator) { this.evaluator = evaluator; }

    public double getProductivityScore() { return productivityScore; }
    public void setProductivityScore(double productivityScore) { 
        this.productivityScore = productivityScore; 
        calculateOverallScore();
    }

    public double getQualityScore() { return qualityScore; }
    public void setQualityScore(double qualityScore) { 
        this.qualityScore = qualityScore; 
        calculateOverallScore();
    }

    public double getAttendanceScore() { return attendanceScore; }
    public void setAttendanceScore(double attendanceScore) { 
        this.attendanceScore = attendanceScore; 
        calculateOverallScore();
    }

    public double getTeamworkScore() { return teamworkScore; }
    public void setTeamworkScore(double teamworkScore) { 
        this.teamworkScore = teamworkScore; 
        calculateOverallScore();
    }

    public double getOverallScore() { return overallScore; }
    public void setOverallScore(double overallScore) { this.overallScore = overallScore; }

    public String getWorkCompleted() { return workCompleted; }
    public void setWorkCompleted(String workCompleted) { this.workCompleted = workCompleted; }

    public String getChallenges() { return challenges; }
    public void setChallenges(String challenges) { this.challenges = challenges; }

    public String getImprovements() { return improvements; }
    public void setImprovements(String improvements) { this.improvements = improvements; }

    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isLocked() { return isLocked; }
    public void setLocked(boolean locked) { isLocked = locked; }

    @Override
    public String toString() {
        return String.format("DailyEvaluation{id=%d, worker='%s', date=%s, overallScore=%.2f, status='%s'}", 
                           id, workerName, evaluationDate, overallScore, status);
    }
} 