package com.example.gobaweredamanagmentsystem.controllers;

import com.example.gobaweredamanagmentsystem.dao.JobAssignmentDAO;
import com.example.gobaweredamanagmentsystem.dao.WorkerDAO;
import com.example.gobaweredamanagmentsystem.dao.JobDAO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.text.Text;
import javafx.scene.layout.StackPane;

import java.util.Objects;

public class DashboardController {

    @FXML private StackPane contentArea;
    @FXML private Text workerCount;
    @FXML private Text jobCount;
    @FXML private Text assignmentCount;
    @FXML private Text statusText;

    @FXML
    public void initialize() {
        updateDashboardStats();
    }

    private void updateDashboardStats() {
        // Update worker count
        int workers = WorkerDAO.getAllWorkers().size();
        workerCount.setText(String.valueOf(workers));

        // Update job count
        int jobs = JobDAO.getAllJobs().size();
        jobCount.setText(String.valueOf(jobs));

        // Update assignment count
        int assignments = JobAssignmentDAO.getAllJobAssignments().size();
        assignmentCount.setText(String.valueOf(assignments));
    }

    @FXML
    private void showDashboard() {
        // Already on dashboard, just update stats
        updateDashboardStats();
    }

    @FXML
    private void showWorkerManagement() {
        try {
            Parent workerView = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/gobaweredamanagmentsystem/worker.fxml")));
            contentArea.getChildren().setAll(workerView);
            statusText.setText("Worker Management Module");
        } catch (Exception e) {
            e.printStackTrace();
            statusText.setText("Error loading Worker Management");
        }
    }

    @FXML
    private void showJobManagement() {
        try {
            Parent jobView = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/gobaweredamanagmentsystem/job.fxml")));
            contentArea.getChildren().setAll(jobView);
            statusText.setText("Job Management Module");
        } catch (Exception e) {
            e.printStackTrace();
            statusText.setText("Error loading Job Management");
        }
    }

    @FXML
    private void showJobAssignment() {
        try {
            Parent jobAssignmentView = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/gobaweredamanagmentsystem/jobassignment.fxml")));
            contentArea.getChildren().setAll(jobAssignmentView);
            statusText.setText("Job Assignment Management Module");
        } catch (Exception e) {
            e.printStackTrace();
            statusText.setText("Error loading Job Assignment Management");
        }
    }

    @FXML
    private void showAttendance() {
        try {
            Parent attendanceView = FXMLLoader.load(getClass().getResource("/com/example/gobaweredamanagmentsystem/attendance.fxml"));
            contentArea.getChildren().setAll(attendanceView);
            statusText.setText("Attendance Tracking Module");
        } catch (Exception e) {
            e.printStackTrace();
            statusText.setText("Error loading Attendance Tracking");
        }
    }

    @FXML
    private void showReports() {
        try {
            Parent reportsView = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/gobaweredamanagmentsystem/reports.fxml")));
            contentArea.getChildren().setAll(reportsView);
            statusText.setText("Reports Module");
        } catch (Exception e) {
            e.printStackTrace();
            statusText.setText("Error loading Reports Module");
        }
    }
    @FXML
    private void showEvaluation() {
        try {
            Parent evaluationView = FXMLLoader.load(getClass().getResource("/com/example/gobaweredamanagmentsystem/evaluation.fxml"));
            contentArea.getChildren().setAll(evaluationView);
            statusText.setText("Evaluation Module");
        } catch (Exception e) {
            e.printStackTrace();
            statusText.setText("Error loading Evaluation Module");
        }
    }
    
    @FXML
    private void showDailyEvaluation() {
        try {
            Parent dailyEvaluationView = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/gobaweredamanagmentsystem/dailyevaluation.fxml")));
            contentArea.getChildren().setAll(dailyEvaluationView);
            statusText.setText("Daily Evaluation Module");
        } catch (Exception e) {
            e.printStackTrace();
            statusText.setText("Error loading Daily Evaluation Module");
        }
    }
    
    @FXML

    private void showSettings() {
        try {
            Parent settingsView = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/gobaweredamanagmentsystem/settings.fxml")));
            contentArea.getChildren().setAll(settingsView);
            statusText.setText("Settings Module");
        } catch (Exception e) {
            e.printStackTrace();
            statusText.setText("Error loading Settings Module");
        }
    }
}