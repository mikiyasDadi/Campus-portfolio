package com.example.gobaweredamanagmentsystem.utils;

import com.example.gobaweredamanagmentsystem.dao.DailyEvaluationDAO;
import com.example.gobaweredamanagmentsystem.dao.WorkerDAO;
import com.example.gobaweredamanagmentsystem.models.DailyEvaluation;
import com.example.gobaweredamanagmentsystem.models.Report;
import com.example.gobaweredamanagmentsystem.models.Worker;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class ReportGenerator {

    private static final String DESKTOP_PATH = System.getProperty("user.home") + "/Desktop";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter REPORT_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");

    public static Report generateWeeklyReport(LocalDate weekStart, String generatedBy) {
        LocalDate weekEnd = weekStart.plusDays(6);
        List<DailyEvaluation> evaluations = DailyEvaluationDAO.getDailyEvaluationsByDateRange(weekStart, weekEnd);
        
        Report report = new Report("Weekly", weekStart, weekEnd, generatedBy);
        populateReportData(report, evaluations);
        
        // Generate summary
        report.setSummary(String.format("Weekly performance report covering %s to %s. " +
                "Total evaluations: %d, Average overall score: %.2f", 
                weekStart.format(DATE_FORMATTER), weekEnd.format(DATE_FORMATTER),
                report.getTotalEvaluations(), report.getAverageOverallScore()));
        
        return report;
    }

    public static Report generateMonthlyReport(LocalDate monthStart, String generatedBy) {
        LocalDate monthEnd = monthStart.plusMonths(1).minusDays(1);
        List<DailyEvaluation> evaluations = DailyEvaluationDAO.getDailyEvaluationsByDateRange(monthStart, monthEnd);
        
        Report report = new Report("Monthly", monthStart, monthEnd, generatedBy);
        populateReportData(report, evaluations);
        
        // Generate summary
        report.setSummary(String.format("Monthly performance report covering %s to %s. " +
                "Total evaluations: %d, Average overall score: %.2f", 
                monthStart.format(DATE_FORMATTER), monthEnd.format(DATE_FORMATTER),
                report.getTotalEvaluations(), report.getAverageOverallScore()));
        
        return report;
    }

    public static Report generateQuarterlyReport(LocalDate quarterStart, String generatedBy) {
        LocalDate quarterEnd = quarterStart.plusMonths(3).minusDays(1);
        List<DailyEvaluation> evaluations = DailyEvaluationDAO.getDailyEvaluationsByDateRange(quarterStart, quarterEnd);
        
        Report report = new Report("Quarterly", quarterStart, quarterEnd, generatedBy);
        populateReportData(report, evaluations);
        
        // Generate summary
        report.setSummary(String.format("Quarterly performance report covering %s to %s. " +
                "Total evaluations: %d, Average overall score: %.2f", 
                quarterStart.format(DATE_FORMATTER), quarterEnd.format(DATE_FORMATTER),
                report.getTotalEvaluations(), report.getAverageOverallScore()));
        
        return report;
    }

    public static Report generateAnnualReport(LocalDate yearStart, String generatedBy) {
        LocalDate yearEnd = yearStart.plusYears(1).minusDays(1);
        List<DailyEvaluation> evaluations = DailyEvaluationDAO.getDailyEvaluationsByDateRange(yearStart, yearEnd);
        
        Report report = new Report("Annual", yearStart, yearEnd, generatedBy);
        populateReportData(report, evaluations);
        
        // Generate summary
        report.setSummary(String.format("Annual performance report covering %s to %s. " +
                "Total evaluations: %d, Average overall score: %.2f", 
                yearStart.format(DATE_FORMATTER), yearEnd.format(DATE_FORMATTER),
                report.getTotalEvaluations(), report.getAverageOverallScore()));
        
        return report;
    }

    private static void populateReportData(Report report, List<DailyEvaluation> evaluations) {
        if (evaluations.isEmpty()) {
            report.setTotalWorkers(0);
            report.setTotalEvaluations(0);
            report.setAverageOverallScore(0.0);
            report.setAverageProductivityScore(0.0);
            report.setAverageQualityScore(0.0);
            report.setAverageAttendanceScore(0.0);
            report.setAverageTeamworkScore(0.0);
            return;
        }

        // Calculate totals and averages
        report.setTotalEvaluations(evaluations.size());
        report.setTotalWorkers((int) evaluations.stream()
                .mapToInt(DailyEvaluation::getWorkerId)
                .distinct()
                .count());

        // Calculate average scores
        double avgOverall = evaluations.stream()
                .mapToDouble(DailyEvaluation::getOverallScore)
                .average()
                .orElse(0.0);
        report.setAverageOverallScore(avgOverall);

        double avgProductivity = evaluations.stream()
                .mapToDouble(DailyEvaluation::getProductivityScore)
                .average()
                .orElse(0.0);
        report.setAverageProductivityScore(avgProductivity);

        double avgQuality = evaluations.stream()
                .mapToDouble(DailyEvaluation::getQualityScore)
                .average()
                .orElse(0.0);
        report.setAverageQualityScore(avgQuality);

        double avgAttendance = evaluations.stream()
                .mapToDouble(DailyEvaluation::getAttendanceScore)
                .average()
                .orElse(0.0);
        report.setAverageAttendanceScore(avgAttendance);

        double avgTeamwork = evaluations.stream()
                .mapToDouble(DailyEvaluation::getTeamworkScore)
                .average()
                .orElse(0.0);
        report.setAverageTeamworkScore(avgTeamwork);

        // Calculate worker performance
        Map<String, Double> workerPerformance = evaluations.stream()
                .collect(Collectors.groupingBy(
                        DailyEvaluation::getWorkerName,
                        Collectors.averagingDouble(DailyEvaluation::getOverallScore)
                ));
        report.setWorkerPerformance(workerPerformance);

        // Find top performers
        List<String> topPerformers = workerPerformance.entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .limit(5)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
        report.setTopPerformers(topPerformers);

        // Generate recommendations
        generateRecommendations(report, evaluations, workerPerformance);
    }

    private static void generateRecommendations(Report report, List<DailyEvaluation> evaluations, 
                                              Map<String, Double> workerPerformance) {
        StringBuilder recommendations = new StringBuilder();
        StringBuilder challenges = new StringBuilder();
        StringBuilder achievements = new StringBuilder();

        // Analyze performance trends
        double overallAvg = report.getAverageOverallScore();
        if (overallAvg >= 4.0) {
            achievements.append("• Excellent overall performance with average score of ").append(String.format("%.2f", overallAvg)).append("\n");
        } else if (overallAvg >= 3.0) {
            achievements.append("• Good overall performance with average score of ").append(String.format("%.2f", overallAvg)).append("\n");
        } else {
            challenges.append("• Below average performance with average score of ").append(String.format("%.2f", overallAvg)).append("\n");
        }

        // Identify areas for improvement
        double productivityAvg = report.getAverageProductivityScore();
        double qualityAvg = report.getAverageQualityScore();
        double attendanceAvg = report.getAverageAttendanceScore();
        double teamworkAvg = report.getAverageTeamworkScore();

        if (productivityAvg < 3.5) {
            challenges.append("• Productivity scores need improvement (avg: ").append(String.format("%.2f", productivityAvg)).append(")\n");
            recommendations.append("• Implement productivity training programs\n");
        }
        if (qualityAvg < 3.5) {
            challenges.append("• Quality scores need improvement (avg: ").append(String.format("%.2f", qualityAvg)).append(")\n");
            recommendations.append("• Establish quality control measures\n");
        }
        if (attendanceAvg < 3.5) {
            challenges.append("• Attendance scores need improvement (avg: ").append(String.format("%.2f", attendanceAvg)).append(")\n");
            recommendations.append("• Review attendance policies and incentives\n");
        }
        if (teamworkAvg < 3.5) {
            challenges.append("• Teamwork scores need improvement (avg: ").append(String.format("%.2f", teamworkAvg)).append(")\n");
            recommendations.append("• Organize team-building activities\n");
        }

        // Top performers recognition
        if (!report.getTopPerformers().isEmpty()) {
            achievements.append("• Top performers: ").append(String.join(", ", report.getTopPerformers())).append("\n");
            recommendations.append("• Recognize and reward top performers\n");
        }

        // General recommendations
        recommendations.append("• Continue regular performance monitoring\n");
        recommendations.append("• Provide regular feedback to all workers\n");
        recommendations.append("• Consider implementing performance-based incentives\n");

        report.setRecommendations(recommendations.toString());
        report.setChallenges(challenges.toString());
        report.setAchievements(achievements.toString());
    }

    public static String exportReportToDesktop(Report report, List<DailyEvaluation> evaluations) {
        try {
            String timestamp = LocalDate.now().format(REPORT_DATE_FORMATTER);
            String fileName = String.format("%s_Report_%s.csv", 
                    report.getReportType(), timestamp);
            Path filePath = Paths.get(DESKTOP_PATH, fileName);

            try (FileWriter writer = new FileWriter(filePath.toFile())) {
                // Write report header
                writer.write("Goba Wereda Management System - " + report.getReportTitle() + "\n");
                writer.write("Generated by: " + report.getGeneratedBy() + "\n");
                writer.write("Generated on: " + report.getGeneratedDate().format(DATE_FORMATTER) + "\n");
                writer.write("Period: " + report.getStartDate().format(DATE_FORMATTER) + " to " + 
                           report.getEndDate().format(DATE_FORMATTER) + "\n");
                writer.write("Status: " + report.getStatus() + "\n\n");

                // Write summary statistics
                writer.write("SUMMARY STATISTICS\n");
                writer.write("Total Workers,Total Evaluations,Average Overall Score,Average Productivity,Average Quality,Average Attendance,Average Teamwork\n");
                writer.write(String.format("%d,%d,%.2f,%.2f,%.2f,%.2f,%.2f\n\n",
                        report.getTotalWorkers(), report.getTotalEvaluations(),
                        report.getAverageOverallScore(), report.getAverageProductivityScore(),
                        report.getAverageQualityScore(), report.getAverageAttendanceScore(),
                        report.getAverageTeamworkScore()));

                // Write top performers
                if (!report.getTopPerformers().isEmpty()) {
                    writer.write("TOP PERFORMERS\n");
                    writer.write("Rank,Worker Name,Average Score\n");
                    for (int i = 0; i < report.getTopPerformers().size(); i++) {
                        String workerName = report.getTopPerformers().get(i);
                        Double score = report.getWorkerPerformance().get(workerName);
                        writer.write(String.format("%d,%s,%.2f\n", i + 1, workerName, score));
                    }
                    writer.write("\n");
                }

                // Write detailed evaluation data
                if (!evaluations.isEmpty()) {
                    writer.write("DETAILED EVALUATIONS\n");
                    writer.write("Date,Worker Name,Evaluator,Productivity Score,Quality Score,Attendance Score,Teamwork Score,Overall Score,Work Completed,Challenges,Improvements,Comments,Status\n");
                    
                    for (DailyEvaluation eval : evaluations) {
                        writer.write(String.format("%s,%s,%s,%.2f,%.2f,%.2f,%.2f,%.2f,\"%s\",\"%s\",\"%s\",\"%s\",%s\n",
                                eval.getEvaluationDate().format(DATE_FORMATTER),
                                eval.getWorkerName(),
                                eval.getEvaluator(),
                                eval.getProductivityScore(),
                                eval.getQualityScore(),
                                eval.getAttendanceScore(),
                                eval.getTeamworkScore(),
                                eval.getOverallScore(),
                                eval.getWorkCompleted() != null ? eval.getWorkCompleted().replace("\"", "\"\"") : "",
                                eval.getChallenges() != null ? eval.getChallenges().replace("\"", "\"\"") : "",
                                eval.getImprovements() != null ? eval.getImprovements().replace("\"", "\"\"") : "",
                                eval.getComments() != null ? eval.getComments().replace("\"", "\"\"") : "",
                                eval.getStatus()));
                    }
                    writer.write("\n");
                }

                // Write recommendations
                if (report.getRecommendations() != null && !report.getRecommendations().isEmpty()) {
                    writer.write("RECOMMENDATIONS\n");
                    writer.write(report.getRecommendations() + "\n\n");
                }

                // Write challenges
                if (report.getChallenges() != null && !report.getChallenges().isEmpty()) {
                    writer.write("CHALLENGES\n");
                    writer.write(report.getChallenges() + "\n\n");
                }

                // Write achievements
                if (report.getAchievements() != null && !report.getAchievements().isEmpty()) {
                    writer.write("ACHIEVEMENTS\n");
                    writer.write(report.getAchievements() + "\n");
                }
            }

            return filePath.toString();
        } catch (IOException e) {
            System.out.println("Error exporting report: " + e.getMessage());
            return null;
        }
    }

    public static String exportDailyEvaluationsToDesktop(List<DailyEvaluation> evaluations, String reportType) {
        try {
            String timestamp = LocalDate.now().format(REPORT_DATE_FORMATTER);
            String fileName = String.format("Daily_Evaluations_%s_%s.csv", reportType, timestamp);
            Path filePath = Paths.get(DESKTOP_PATH, fileName);

            try (FileWriter writer = new FileWriter(filePath.toFile())) {
                // Write header
                writer.write("Daily Evaluations Export - " + reportType + "\n");
                writer.write("Generated on: " + LocalDate.now().format(DATE_FORMATTER) + "\n");
                writer.write("Total Records: " + evaluations.size() + "\n\n");

                // Write data
                writer.write("ID,Date,Worker Name,Evaluator,Productivity Score,Quality Score,Attendance Score,Teamwork Score,Overall Score,Work Completed,Challenges,Improvements,Comments,Status,Locked\n");
                
                for (DailyEvaluation eval : evaluations) {
                    writer.write(String.format("%d,%s,%s,%s,%.2f,%.2f,%.2f,%.2f,%.2f,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s\n",
                            eval.getId(),
                            eval.getEvaluationDate().format(DATE_FORMATTER),
                            eval.getWorkerName(),
                            eval.getEvaluator(),
                            eval.getProductivityScore(),
                            eval.getQualityScore(),
                            eval.getAttendanceScore(),
                            eval.getTeamworkScore(),
                            eval.getOverallScore(),
                            eval.getWorkCompleted() != null ? eval.getWorkCompleted().replace("\"", "\"\"") : "",
                            eval.getChallenges() != null ? eval.getChallenges().replace("\"", "\"\"") : "",
                            eval.getImprovements() != null ? eval.getImprovements().replace("\"", "\"\"") : "",
                            eval.getComments() != null ? eval.getComments().replace("\"", "\"\"") : "",
                            eval.getStatus(),
                            eval.isLocked() ? "Yes" : "No"));
                }
            }

            return filePath.toString();
        } catch (IOException e) {
            System.out.println("Error exporting daily evaluations: " + e.getMessage());
            return null;
        }
    }
} 