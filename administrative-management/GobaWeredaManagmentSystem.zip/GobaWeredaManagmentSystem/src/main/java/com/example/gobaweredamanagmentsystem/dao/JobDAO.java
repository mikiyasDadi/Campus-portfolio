package com.example.gobaweredamanagmentsystem.dao;

import com.example.gobaweredamanagmentsystem.models.Job;
import com.example.gobaweredamanagmentsystem.utils.DatabaseHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JobDAO {

    // Add a new job
    public static boolean addJob(Job job) {
        String sql = "INSERT INTO job (title, description, department, requirements, salary, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, job.getTitle());
            pstmt.setString(2, job.getDescription());
            pstmt.setString(3, job.getDepartment());
            pstmt.setString(4, job.getRequirements());
            pstmt.setDouble(5, job.getSalary());
            pstmt.setString(6, job.getStatus());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error adding job: " + e.getMessage());
            return false;
        }
    }

    // Update an existing job
    public static boolean updateJob(Job job) {
        String sql = "UPDATE job SET title=?, description=?, department=?, requirements=?, salary=?, status=? WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, job.getTitle());
            pstmt.setString(2, job.getDescription());
            pstmt.setString(3, job.getDepartment());
            pstmt.setString(4, job.getRequirements());
            pstmt.setDouble(5, job.getSalary());
            pstmt.setString(6, job.getStatus());
            pstmt.setInt(7, job.getId());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error updating job: " + e.getMessage());
            return false;
        }
    }

    // Delete a job by id
    public static boolean deleteJob(int id) {
        String sql = "DELETE FROM job WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error deleting job: " + e.getMessage());
            return false;
        }
    }

    // Get all jobs
    public static List<Job> getAllJobs() {
        List<Job> jobs = new ArrayList<>();
        String sql = "SELECT * FROM job";
        try (Connection conn = DatabaseHelper.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Job job = new Job(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("department"),
                        rs.getString("requirements"),
                        rs.getDouble("salary"),
                        rs.getString("status")
                );
                jobs.add(job);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching jobs: " + e.getMessage());
        }
        return jobs;
    }

    // Get a job by id
    public static Job getJobById(int id) {
        String sql = "SELECT * FROM job WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Job(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("department"),
                        rs.getString("requirements"),
                        rs.getDouble("salary"),
                        rs.getString("status")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error fetching job by id: " + e.getMessage());
        }
        return null;
    }
}
