package com.example.gobaweredamanagmentsystem.models;

public class Attendance {
    private int id;
    private int workerId;
    private String date;      // Format: YYYY-MM-DD
    private String status;    // Present, Absent, Late, etc.
    private String notes;
    private String workerName; // For display

    public Attendance() {}

    public Attendance(int workerId, String date, String status, String notes) {
        this.workerId = workerId;
        this.date = date;
        this.status = status;
        this.notes = notes;
    }

    public Attendance(int id, int workerId, String date, String status, String notes) {
        this.id = id;
        this.workerId = workerId;
        this.date = date;
        this.status = status;
        this.notes = notes;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getWorkerId() { return workerId; }
    public void setWorkerId(int workerId) { this.workerId = workerId; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getWorkerName() { return workerName; }
    public void setWorkerName(String workerName) { this.workerName = workerName; }
}