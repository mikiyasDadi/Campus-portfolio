package com.example.gobaweredamanagmentsystem.controllers;


import com.example.gobaweredamanagmentsystem.dao.JobDAO;
import com.example.gobaweredamanagmentsystem.models.Job;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
public class JobController {

    @FXML private TextField searchField;
    @FXML private TableView<Job> jobTable;
    @FXML private TableColumn<Job, Integer> idCol;
    @FXML private TableColumn<Job, String> titleCol;
    @FXML private TableColumn<Job, String> descriptionCol;
    @FXML private TableColumn<Job, String> departmentCol;
    @FXML private TableColumn<Job, String> requirementsCol;
    @FXML private TableColumn<Job, Double> salaryCol;
    @FXML private TableColumn<Job, String> statusCol;

    @FXML private TextField titleField;
    @FXML private TextField departmentField;
    @FXML private TextField salaryField;
    @FXML private ComboBox<String> statusComboBox;
    @FXML private TextArea descriptionArea;
    @FXML private TextArea requirementsArea;

    private ObservableList<Job> jobList = FXCollections.observableArrayList();
    private FilteredList<Job> filteredData;
    private SortedList<Job> sortedData;
    @FXML
    public void initialize() {
        // Set up status combo box
        statusComboBox.setItems(FXCollections.observableArrayList("Active", "Inactive", "Pending"));

        // Set up table columns
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        titleCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getTitle()));
        descriptionCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDescription()));
        departmentCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDepartment()));
        requirementsCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getRequirements()));
        salaryCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleDoubleProperty(cellData.getValue().getSalary()).asObject());
        statusCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));

        // Load data
        loadJobs();

        filteredData = new FilteredList<>(jobList, p -> true);
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filteredData.setPredicate(job -> {
                if (newVal == null || newVal.isEmpty()) return true;
                String filter = newVal.toLowerCase();
                return job.getTitle().toLowerCase().contains(filter)
                        || job.getDepartment().toLowerCase().contains(filter)
                        || job.getStatus().toLowerCase().contains(filter);
            });
        });

        sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(jobTable.comparatorProperty());
        jobTable.setItems(sortedData);


        // When a row is selected, fill the fields
        jobTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                titleField.setText(newSel.getTitle());
                departmentField.setText(newSel.getDepartment());
                salaryField.setText(String.valueOf(newSel.getSalary()));
                statusComboBox.setValue(newSel.getStatus());
                descriptionArea.setText(newSel.getDescription());
                requirementsArea.setText(newSel.getRequirements());
            }
        });
    }

    private void loadJobs() {
        jobList.setAll(JobDAO.getAllJobs());
        jobTable.setItems(jobList);
    }

    @FXML
    private void handleAdd() {
        if (titleField.getText().trim().isEmpty()) {
            showAlert("Error", "Job title is required!");
            return;
        }

        try {
            double salary = Double.parseDouble(salaryField.getText().trim());

            Job job = new Job(
                    titleField.getText().trim(),
                    descriptionArea.getText().trim(),
                    departmentField.getText().trim(),
                    requirementsArea.getText().trim(),
                    salary,
                    statusComboBox.getValue() != null ? statusComboBox.getValue() : "Active"
            );

            if (JobDAO.addJob(job)) {
                loadJobs();
                clearFields();
                showAlert("Success", "Job added successfully!");
            } else {
                showAlert("Error", "Could not add job.");
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Please enter a valid salary amount!");
        }
    }

    @FXML
    private void handleEdit() {
        Job selected = jobTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a job to edit.");
            return;
        }

        if (titleField.getText().trim().isEmpty()) {
            showAlert("Error", "Job title is required!");
            return;
        }

        try {
            double salary = Double.parseDouble(salaryField.getText().trim());

            selected.setTitle(titleField.getText().trim());
            selected.setDescription(descriptionArea.getText().trim());
            selected.setDepartment(departmentField.getText().trim());
            selected.setRequirements(requirementsArea.getText().trim());
            selected.setSalary(salary);
            selected.setStatus(statusComboBox.getValue() != null ? statusComboBox.getValue() : "Active");

            if (JobDAO.updateJob(selected)) {
                loadJobs();
                clearFields();
                showAlert("Success", "Job updated successfully!");
            } else {
                showAlert("Error", "Could not update job.");
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Please enter a valid salary amount!");
        }
    }

    @FXML
    private void handleDelete() {
        Job selected = jobTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a job to delete.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Delete");
        alert.setHeaderText("Delete Job");
        alert.setContentText("Are you sure you want to delete the job: " + selected.getTitle() + "?");

        if (alert.showAndWait().orElse(null) == ButtonType.OK) {
            if (JobDAO.deleteJob(selected.getId())) {
                loadJobs();
                clearFields();
                showAlert("Success", "Job deleted successfully!");
            } else {
                showAlert("Error", "Could not delete job.");
            }
        }
    }

    @FXML
    private void handleClear() {
        clearFields();
    }

    private void clearFields() {
        titleField.clear();
        departmentField.clear();
        salaryField.clear();
        statusComboBox.setValue(null);
        descriptionArea.clear();
        requirementsArea.clear();
        jobTable.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
