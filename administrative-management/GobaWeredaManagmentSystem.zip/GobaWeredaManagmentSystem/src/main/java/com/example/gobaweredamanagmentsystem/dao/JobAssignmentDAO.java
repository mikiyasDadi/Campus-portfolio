package com.example.gobaweredamanagmentsystem.dao;

import com.example.gobaweredamanagmentsystem.models.JobAssignment;
import com.example.gobaweredamanagmentsystem.utils.DatabaseHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JobAssignmentDAO {

    // Add a new job assignment
    public static boolean addJobAssignment(JobAssignment assignment) {
        String sql = "INSERT INTO job_assignment (worker_id, job_id, start_date, end_date, status, notes) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, assignment.getWorkerId());
            pstmt.setInt(2, assignment.getJobId());
            pstmt.setString(3, assignment.getStartDate());
            pstmt.setString(4, assignment.getEndDate());
            pstmt.setString(5, assignment.getStatus());
            pstmt.setString(6, assignment.getNotes());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error adding job assignment: " + e.getMessage());
            return false;
        }
    }

    // Update an existing job assignment
    public static boolean updateJobAssignment(JobAssignment assignment) {
        String sql = "UPDATE job_assignment SET worker_id=?, job_id=?, start_date=?, end_date=?, status=?, notes=? WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, assignment.getWorkerId());
            pstmt.setInt(2, assignment.getJobId());
            pstmt.setString(3, assignment.getStartDate());
            pstmt.setString(4, assignment.getEndDate());
            pstmt.setString(5, assignment.getStatus());
            pstmt.setString(6, assignment.getNotes());
            pstmt.setInt(7, assignment.getId());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error updating job assignment: " + e.getMessage());
            return false;
        }
    }

    // Delete a job assignment by id
    public static boolean deleteJobAssignment(int id) {
        String sql = "DELETE FROM job_assignment WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error deleting job assignment: " + e.getMessage());
            return false;
        }
    }

    // Get all job assignments with worker and job names
    public static List<JobAssignment> getAllJobAssignments() {
        List<JobAssignment> assignments = new ArrayList<>();
        String sql = "SELECT ja.*, w.name as worker_name, j.title as job_title " +
                "FROM job_assignment ja " +
                "JOIN worker w ON ja.worker_id = w.id " +
                "JOIN job j ON ja.job_id = j.id " +
                "ORDER BY ja.start_date DESC";
        try (Connection conn = DatabaseHelper.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                JobAssignment assignment = new JobAssignment(
                        rs.getInt("id"),
                        rs.getInt("worker_id"),
                        rs.getInt("job_id"),
                        rs.getString("start_date"),
                        rs.getString("end_date"),
                        rs.getString("status"),
                        rs.getString("notes")
                );
                assignment.setWorkerName(rs.getString("worker_name"));
                assignment.setJobTitle(rs.getString("job_title"));
                assignments.add(assignment);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching job assignments: " + e.getMessage());
        }
        return assignments;
    }

    // Get a job assignment by id
    public static JobAssignment getJobAssignmentById(int id) {
        String sql = "SELECT ja.*, w.name as worker_name, j.title as job_title " +
                "FROM job_assignment ja " +
                "JOIN worker w ON ja.worker_id = w.id " +
                "JOIN job j ON ja.job_id = j.id " +
                "WHERE ja.id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                JobAssignment assignment = new JobAssignment(
                        rs.getInt("id"),
                        rs.getInt("worker_id"),
                        rs.getInt("job_id"),
                        rs.getString("start_date"),
                        rs.getString("end_date"),
                        rs.getString("status"),
                        rs.getString("notes")
                );
                assignment.setWorkerName(rs.getString("worker_name"));
                assignment.setJobTitle(rs.getString("job_title"));
                return assignment;
            }
        } catch (SQLException e) {
            System.out.println("Error fetching job assignment by id: " + e.getMessage());
        }
        return null;
    }
}