package com.example.gobaweredamanagmentsystem.models;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class Report {
    private int id;
    private String reportType; // "Weekly", "Monthly", "Quarterly", "Annual"
    private LocalDate startDate;
    private LocalDate endDate;
    private String generatedBy;
    private LocalDate generatedDate;
    private String status; // "Draft", "Final", "Archived"
    private boolean isLocked; // Prevents editing after finalization
    
    // Aggregated data
    private int totalWorkers;
    private int totalEvaluations;
    private double averageOverallScore;
    private double averageProductivityScore;
    private double averageQualityScore;
    private double averageAttendanceScore;
    private double averageTeamworkScore;
    
    // Performance metrics
    private Map<String, Double> workerPerformance; // Worker name -> average score
    private Map<String, Integer> attendanceSummary; // Status -> count
    private List<String> topPerformers;
    private List<String> improvementAreas;
    
    // Report content
    private String summary;
    private String recommendations;
    private String challenges;
    private String achievements;

    public Report() {}

    public Report(String reportType, LocalDate startDate, LocalDate endDate, String generatedBy) {
        this.reportType = reportType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.generatedBy = generatedBy;
        this.generatedDate = LocalDate.now();
        this.status = "Draft";
        this.isLocked = false;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getReportType() { return reportType; }
    public void setReportType(String reportType) { this.reportType = reportType; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public String getGeneratedBy() { return generatedBy; }
    public void setGeneratedBy(String generatedBy) { this.generatedBy = generatedBy; }

    public LocalDate getGeneratedDate() { return generatedDate; }
    public void setGeneratedDate(LocalDate generatedDate) { this.generatedDate = generatedDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isLocked() { return isLocked; }
    public void setLocked(boolean locked) { isLocked = locked; }

    public int getTotalWorkers() { return totalWorkers; }
    public void setTotalWorkers(int totalWorkers) { this.totalWorkers = totalWorkers; }

    public int getTotalEvaluations() { return totalEvaluations; }
    public void setTotalEvaluations(int totalEvaluations) { this.totalEvaluations = totalEvaluations; }

    public double getAverageOverallScore() { return averageOverallScore; }
    public void setAverageOverallScore(double averageOverallScore) { this.averageOverallScore = averageOverallScore; }

    public double getAverageProductivityScore() { return averageProductivityScore; }
    public void setAverageProductivityScore(double averageProductivityScore) { this.averageProductivityScore = averageProductivityScore; }

    public double getAverageQualityScore() { return averageQualityScore; }
    public void setAverageQualityScore(double averageQualityScore) { this.averageQualityScore = averageQualityScore; }

    public double getAverageAttendanceScore() { return averageAttendanceScore; }
    public void setAverageAttendanceScore(double averageAttendanceScore) { this.averageAttendanceScore = averageAttendanceScore; }

    public double getAverageTeamworkScore() { return averageTeamworkScore; }
    public void setAverageTeamworkScore(double averageTeamworkScore) { this.averageTeamworkScore = averageTeamworkScore; }

    public Map<String, Double> getWorkerPerformance() { return workerPerformance; }
    public void setWorkerPerformance(Map<String, Double> workerPerformance) { this.workerPerformance = workerPerformance; }

    public Map<String, Integer> getAttendanceSummary() { return attendanceSummary; }
    public void setAttendanceSummary(Map<String, Integer> attendanceSummary) { this.attendanceSummary = attendanceSummary; }

    public List<String> getTopPerformers() { return topPerformers; }
    public void setTopPerformers(List<String> topPerformers) { this.topPerformers = topPerformers; }

    public List<String> getImprovementAreas() { return improvementAreas; }
    public void setImprovementAreas(List<String> improvementAreas) { this.improvementAreas = improvementAreas; }

    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }

    public String getRecommendations() { return recommendations; }
    public void setRecommendations(String recommendations) { this.recommendations = recommendations; }

    public String getChallenges() { return challenges; }
    public void setChallenges(String challenges) { this.challenges = challenges; }

    public String getAchievements() { return achievements; }
    public void setAchievements(String achievements) { this.achievements = achievements; }

    public String getReportTitle() {
        return String.format("%s Report (%s - %s)", reportType, startDate, endDate);
    }

    @Override
    public String toString() {
        return String.format("Report{id=%d, type='%s', period='%s to %s', status='%s', avgScore=%.2f}", 
                           id, reportType, startDate, endDate, status, averageOverallScore);
    }
} 