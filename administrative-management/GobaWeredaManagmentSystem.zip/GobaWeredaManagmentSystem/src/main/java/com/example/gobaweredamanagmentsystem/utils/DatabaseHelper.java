package com.example.gobaweredamanagmentsystem.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseHelper {
    private static final String DB_URL = "jdbc:sqlite:organization.db";

    // Connect to the SQLite database
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    // Create the Worker table if it doesn't exist
    public static void createWorkerTable() {
        String sql = "CREATE TABLE IF NOT EXISTS worker ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "name TEXT NOT NULL,"
                + "gender TEXT,"
                + "date_of_birth TEXT,"
                + "contact TEXT,"
                + "address TEXT,"
                + "hire_date TEXT,"
                + "position TEXT,"
                + "status TEXT DEFAULT 'Active'"
                + ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Worker table created or already exists.");
        } catch (SQLException e) {
            System.out.println("Error creating Worker table: " + e.getMessage());
        }

    }

    // Add this method to your DatabaseHelper class
    public static void createJobTable() {
        String sql = "CREATE TABLE IF NOT EXISTS job ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "title TEXT NOT NULL,"
                + "description TEXT,"
                + "department TEXT,"
                + "requirements TEXT,"
                + "salary REAL,"
                + "status TEXT DEFAULT 'Active'"
                + ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Job table created or already exists.");
        } catch (SQLException e) {
            System.out.println("Error creating Job table: " + e.getMessage());
        }
    }
    // Add this method to your DatabaseHelper class
    public static void createJobAssignmentTable() {
        String sql = "CREATE TABLE IF NOT EXISTS job_assignment ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "worker_id INTEGER NOT NULL,"
                + "job_id INTEGER NOT NULL,"
                + "start_date TEXT NOT NULL,"
                + "end_date TEXT,"
                + "status TEXT DEFAULT 'Active',"
                + "notes TEXT,"
                + "FOREIGN KEY (worker_id) REFERENCES worker (id),"
                + "FOREIGN KEY (job_id) REFERENCES job (id)"
                + ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Job Assignment table created or already exists.");
        } catch (SQLException e) {
            System.out.println("Error creating Job Assignment table: " + e.getMessage());
        }
    }
    public static void createAttendanceTable() {
        String sql = "CREATE TABLE IF NOT EXISTS attendance ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "worker_id INTEGER NOT NULL,"
                + "date TEXT NOT NULL,"
                + "status TEXT NOT NULL,"
                + "notes TEXT,"
                + "FOREIGN KEY (worker_id) REFERENCES worker (id)"
                + ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Attendance table created or already exists.");
        } catch (SQLException e) {
            System.out.println("Error creating Attendance table: " + e.getMessage());
        }
    }
    public static void createEvaluationTable() {
        String sql = "CREATE TABLE IF NOT EXISTS evaluation ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "worker_id INTEGER NOT NULL,"
                + "evaluator TEXT,"
                + "date TEXT NOT NULL,"
                + "score REAL,"
                + "comments TEXT,"
                + "FOREIGN KEY (worker_id) REFERENCES worker (id)"
                + ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Evaluation table created or already exists.");
        } catch (SQLException e) {
            System.out.println("Error creating Evaluation table: " + e.getMessage());
        }
    }

    public static void createDailyEvaluationTable() {
        String sql = "CREATE TABLE IF NOT EXISTS daily_evaluation ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "worker_id INTEGER NOT NULL,"
                + "evaluation_date TEXT NOT NULL,"
                + "evaluator TEXT NOT NULL,"
                + "productivity_score REAL NOT NULL,"
                + "quality_score REAL NOT NULL,"
                + "attendance_score REAL NOT NULL,"
                + "teamwork_score REAL NOT NULL,"
                + "overall_score REAL NOT NULL,"
                + "work_completed TEXT,"
                + "challenges TEXT,"
                + "improvements TEXT,"
                + "comments TEXT,"
                + "status TEXT DEFAULT 'Pending',"
                + "is_locked INTEGER DEFAULT 0,"
                + "created_at TEXT DEFAULT CURRENT_TIMESTAMP,"
                + "FOREIGN KEY (worker_id) REFERENCES worker (id)"
                + ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Daily Evaluation table created or already exists.");
        } catch (SQLException e) {
            System.out.println("Error creating Daily Evaluation table: " + e.getMessage());
        }
    }

    public static void createReportTable() {
        String sql = "CREATE TABLE IF NOT EXISTS report ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "report_type TEXT NOT NULL,"
                + "start_date TEXT NOT NULL,"
                + "end_date TEXT NOT NULL,"
                + "generated_by TEXT NOT NULL,"
                + "generated_date TEXT NOT NULL,"
                + "status TEXT DEFAULT 'Draft',"
                + "is_locked INTEGER DEFAULT 0,"
                + "total_workers INTEGER DEFAULT 0,"
                + "total_evaluations INTEGER DEFAULT 0,"
                + "average_overall_score REAL DEFAULT 0.0,"
                + "average_productivity_score REAL DEFAULT 0.0,"
                + "average_quality_score REAL DEFAULT 0.0,"
                + "average_attendance_score REAL DEFAULT 0.0,"
                + "average_teamwork_score REAL DEFAULT 0.0,"
                + "summary TEXT,"
                + "recommendations TEXT,"
                + "challenges TEXT,"
                + "achievements TEXT,"
                + "created_at TEXT DEFAULT CURRENT_TIMESTAMP"
                + ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Report table created or already exists.");
        } catch (SQLException e) {
            System.out.println("Error creating Report table: " + e.getMessage());
        }
    }

    public static void createUserPermissionsTable() {
        String sql = "CREATE TABLE IF NOT EXISTS user_permissions ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "user_id INTEGER NOT NULL,"
                + "permission_type TEXT NOT NULL,"
                + "can_create INTEGER DEFAULT 0,"
                + "can_read INTEGER DEFAULT 1,"
                + "can_update INTEGER DEFAULT 0,"
                + "can_delete INTEGER DEFAULT 0,"
                + "can_export INTEGER DEFAULT 0,"
                + "can_generate_reports INTEGER DEFAULT 0,"
                + "FOREIGN KEY (user_id) REFERENCES user (id)"
                + ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("User Permissions table created or already exists.");
        } catch (SQLException e) {
            System.out.println("Error creating User Permissions table: " + e.getMessage());
        }
    }
    public static void createUserTable() {
        String sql = "CREATE TABLE IF NOT EXISTS user ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "username TEXT NOT NULL UNIQUE,"
                + "password TEXT NOT NULL,"
                + "role TEXT NOT NULL"
                + ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("User table created or already exists.");
        } catch (SQLException e) {
            System.out.println("Error creating User table: " + e.getMessage());
        }
    }
}