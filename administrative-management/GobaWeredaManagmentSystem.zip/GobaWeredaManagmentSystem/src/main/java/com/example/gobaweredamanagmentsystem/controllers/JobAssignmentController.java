package com.example.gobaweredamanagmentsystem.controllers;

import com.example.gobaweredamanagmentsystem.dao.JobAssignmentDAO;
import com.example.gobaweredamanagmentsystem.dao.WorkerDAO;
import com.example.gobaweredamanagmentsystem.dao.JobDAO;
import com.example.gobaweredamanagmentsystem.models.JobAssignment;
import com.example.gobaweredamanagmentsystem.models.Worker;
import com.example.gobaweredamanagmentsystem.models.Job;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import java.util.List;

public class JobAssignmentController {

    @FXML private TextField searchField;
    @FXML private TableView<JobAssignment> assignmentTable;
    @FXML private TableColumn<JobAssignment, Integer> idCol;
    @FXML private TableColumn<JobAssignment, String> workerNameCol;
    @FXML private TableColumn<JobAssignment, String> jobTitleCol;
    @FXML private TableColumn<JobAssignment, String> startDateCol;
    @FXML private TableColumn<JobAssignment, String> endDateCol;
    @FXML private TableColumn<JobAssignment, String> statusCol;
    @FXML private TableColumn<JobAssignment, String> notesCol;

    @FXML private ComboBox<Worker> workerComboBox;
    @FXML private ComboBox<Job> jobComboBox;
    @FXML private ComboBox<String> statusComboBox;
    @FXML private TextField startDateField;
    @FXML private TextField endDateField;
    @FXML private TextField notesField;
    @FXML private Text statusText;

    private final ObservableList<JobAssignment> assignmentList = FXCollections.observableArrayList();
    private final ObservableList<Worker> workerList = FXCollections.observableArrayList();
    private final ObservableList<Job> jobList = FXCollections.observableArrayList();
    private FilteredList<JobAssignment> filteredData;
    private SortedList<JobAssignment> sortedData;
    @FXML
    public void initialize() {
        setupTableColumns();
        setupComboBoxes();
        loadData();

        filteredData = new FilteredList<>(assignmentList, p -> true);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filteredData.setPredicate(assignment -> {
                if (newVal == null || newVal.isEmpty()) return true;
                String filter = newVal.toLowerCase();
                return (assignment.getWorkerName() != null && assignment.getWorkerName().toLowerCase().contains(filter))
                        || (assignment.getJobTitle() != null && assignment.getJobTitle().toLowerCase().contains(filter))
                        || (assignment.getStatus() != null && assignment.getStatus().toLowerCase().contains(filter));
            });
        });

        sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(assignmentTable.comparatorProperty());
        assignmentTable.setItems(sortedData);


        setupTableSelection();

    }

    private void setupTableColumns() {
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        workerNameCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getWorkerName()));
        jobTitleCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getJobTitle()));
        startDateCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStartDate()));
        endDateCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getEndDate()));
        statusCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));
        notesCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getNotes()));
    }

    private void setupComboBoxes() {
        // Setup status combo box
        statusComboBox.setItems(FXCollections.observableArrayList("Active", "Completed", "Terminated"));

        // Setup worker combo box
        workerList.setAll(WorkerDAO.getAllWorkers());
        workerComboBox.setItems(workerList);
        workerComboBox.setCellFactory(param -> new ListCell<Worker>() {
            @Override
            protected void updateItem(Worker item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getName() + " (ID: " + item.getId() + ")");
                }
            }
        });
        workerComboBox.setButtonCell(workerComboBox.getCellFactory().call(null));

        // Setup job combo box
        jobList.setAll(JobDAO.getAllJobs());
        jobComboBox.setItems(jobList);
        jobComboBox.setCellFactory(param -> new ListCell<Job>() {
            @Override
            protected void updateItem(Job item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getTitle() + " - " + item.getDepartment());
                }
            }
        });
        jobComboBox.setButtonCell(jobComboBox.getCellFactory().call(null));
    }

    private void loadData() {
        assignmentList.setAll(JobAssignmentDAO.getAllJobAssignments());
        assignmentTable.setItems(assignmentList);
        statusText.setText("Loaded " + assignmentList.size() + " assignments");
    }

    private void setupTableSelection() {
        assignmentTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                // Find and select the worker
                for (Worker worker : workerList) {
                    if (worker.getId() == newSel.getWorkerId()) {
                        workerComboBox.setValue(worker);
                        break;
                    }
                }

                // Find and select the job
                for (Job job : jobList) {
                    if (job.getId() == newSel.getJobId()) {
                        jobComboBox.setValue(job);
                        break;
                    }
                }

                statusComboBox.setValue(newSel.getStatus());
                startDateField.setText(newSel.getStartDate());
                endDateField.setText(newSel.getEndDate() != null ? newSel.getEndDate() : "");
                notesField.setText(newSel.getNotes() != null ? newSel.getNotes() : "");
            }
        });
    }

    @FXML
    private void handleAdd() {
        if (!validateForm()) return;

        JobAssignment assignment = new JobAssignment(
                workerComboBox.getValue().getId(),
                jobComboBox.getValue().getId(),
                startDateField.getText().trim(),
                endDateField.getText().trim().isEmpty() ? null : endDateField.getText().trim(),
                statusComboBox.getValue(),
                notesField.getText().trim()
        );

        if (JobAssignmentDAO.addJobAssignment(assignment)) {
            loadData();
            clearForm();
            showAlert("Success", "Job assignment added successfully!");
        } else {
            showAlert("Error", "Could not add job assignment.");
        }
    }

    @FXML
    private void handleEdit() {
        JobAssignment selected = assignmentTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select an assignment to edit.");
            return;
        }

        if (!validateForm()) return;

        selected.setWorkerId(workerComboBox.getValue().getId());
        selected.setJobId(jobComboBox.getValue().getId());
        selected.setStartDate(startDateField.getText().trim());
        selected.setEndDate(endDateField.getText().trim().isEmpty() ? null : endDateField.getText().trim());
        selected.setStatus(statusComboBox.getValue());
        selected.setNotes(notesField.getText().trim());

        if (JobAssignmentDAO.updateJobAssignment(selected)) {
            loadData();
            clearForm();
            showAlert("Success", "Job assignment updated successfully!");
        } else {
            showAlert("Error", "Could not update job assignment.");
        }
    }

    @FXML
    private void handleDelete() {
        JobAssignment selected = assignmentTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select an assignment to delete.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Delete");
        alert.setHeaderText("Delete Job Assignment");
        alert.setContentText("Are you sure you want to delete this assignment?");

        if (alert.showAndWait().orElse(null) == ButtonType.OK) {
            if (JobAssignmentDAO.deleteJobAssignment(selected.getId())) {
                loadData();
                clearForm();
                showAlert("Success", "Job assignment deleted successfully!");
            } else {
                showAlert("Error", "Could not delete job assignment.");
            }
        }
    }

    @FXML
    private void handleClear() {
        clearForm();
    }

    @FXML
    private void handleRefresh() {
        loadData();
        showAlert("Info", "Data refreshed successfully!");
    }

    @FXML
    private void handleExport() {
        showAlert("Info", "Export functionality will be implemented soon!");
    }

    @FXML
    private void handleViewActive() {
        // Filter to show only active assignments
        List<JobAssignment> activeAssignments = assignmentList.stream()
                .filter(a -> "Active".equals(a.getStatus()))
                .toList();
        assignmentTable.setItems(FXCollections.observableArrayList(activeAssignments));
        statusText.setText("Showing " + activeAssignments.size() + " active assignments");
    }

    private boolean validateForm() {
        if (workerComboBox.getValue() == null) {
            showAlert("Validation Error", "Please select a worker.");
            return false;
        }
        if (jobComboBox.getValue() == null) {
            showAlert("Validation Error", "Please select a job.");
            return false;
        }
        if (startDateField.getText().trim().isEmpty()) {
            showAlert("Validation Error", "Please enter a start date.");
            return false;
        }
        if (statusComboBox.getValue() == null) {
            showAlert("Validation Error", "Please select a status.");
            return false;
        }
        return true;
    }

    private void clearForm() {
        workerComboBox.setValue(null);
        jobComboBox.setValue(null);
        statusComboBox.setValue(null);
        startDateField.clear();
        endDateField.clear();
        notesField.clear();
        assignmentTable.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}