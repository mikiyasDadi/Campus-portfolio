package com.example.gobaweredamanagmentsystem.dao;

import com.example.gobaweredamanagmentsystem.models.DailyEvaluation;
import com.example.gobaweredamanagmentsystem.utils.DatabaseHelper;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DailyEvaluationDAO {

    public static boolean addDailyEvaluation(DailyEvaluation evaluation) {
        String sql = "INSERT INTO daily_evaluation (worker_id, evaluation_date, evaluator, " +
                    "productivity_score, quality_score, attendance_score, teamwork_score, " +
                    "overall_score, work_completed, challenges, improvements, comments, status, is_locked) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, evaluation.getWorkerId());
            pstmt.setString(2, evaluation.getEvaluationDate().toString());
            pstmt.setString(3, evaluation.getEvaluator());
            pstmt.setDouble(4, evaluation.getProductivityScore());
            pstmt.setDouble(5, evaluation.getQualityScore());
            pstmt.setDouble(6, evaluation.getAttendanceScore());
            pstmt.setDouble(7, evaluation.getTeamworkScore());
            pstmt.setDouble(8, evaluation.getOverallScore());
            pstmt.setString(9, evaluation.getWorkCompleted());
            pstmt.setString(10, evaluation.getChallenges());
            pstmt.setString(11, evaluation.getImprovements());
            pstmt.setString(12, evaluation.getComments());
            pstmt.setString(13, evaluation.getStatus());
            pstmt.setInt(14, evaluation.isLocked() ? 1 : 0);
            
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error adding daily evaluation: " + e.getMessage());
            return false;
        }
    }

    public static boolean updateDailyEvaluation(DailyEvaluation evaluation) {
        // Check if evaluation is locked
        if (isEvaluationLocked(evaluation.getId())) {
            System.out.println("Cannot update locked evaluation");
            return false;
        }

        String sql = "UPDATE daily_evaluation SET worker_id=?, evaluation_date=?, evaluator=?, " +
                    "productivity_score=?, quality_score=?, attendance_score=?, teamwork_score=?, " +
                    "overall_score=?, work_completed=?, challenges=?, improvements=?, comments=?, status=? " +
                    "WHERE id=?";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, evaluation.getWorkerId());
            pstmt.setString(2, evaluation.getEvaluationDate().toString());
            pstmt.setString(3, evaluation.getEvaluator());
            pstmt.setDouble(4, evaluation.getProductivityScore());
            pstmt.setDouble(5, evaluation.getQualityScore());
            pstmt.setDouble(6, evaluation.getAttendanceScore());
            pstmt.setDouble(7, evaluation.getTeamworkScore());
            pstmt.setDouble(8, evaluation.getOverallScore());
            pstmt.setString(9, evaluation.getWorkCompleted());
            pstmt.setString(10, evaluation.getChallenges());
            pstmt.setString(11, evaluation.getImprovements());
            pstmt.setString(12, evaluation.getComments());
            pstmt.setString(13, evaluation.getStatus());
            pstmt.setInt(14, evaluation.getId());
            
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error updating daily evaluation: " + e.getMessage());
            return false;
        }
    }

    public static boolean deleteDailyEvaluation(int id) {
        // Check if evaluation is locked
        if (isEvaluationLocked(id)) {
            System.out.println("Cannot delete locked evaluation");
            return false;
        }

        String sql = "DELETE FROM daily_evaluation WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error deleting daily evaluation: " + e.getMessage());
            return false;
        }
    }

    public static boolean lockEvaluation(int id) {
        String sql = "UPDATE daily_evaluation SET is_locked=1, status='Completed' WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error locking evaluation: " + e.getMessage());
            return false;
        }
    }

    public static boolean isEvaluationLocked(int id) {
        String sql = "SELECT is_locked FROM daily_evaluation WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("is_locked") == 1;
            }
        } catch (SQLException e) {
            System.out.println("Error checking evaluation lock status: " + e.getMessage());
        }
        return false;
    }

    public static List<DailyEvaluation> getAllDailyEvaluations() {
        List<DailyEvaluation> evaluations = new ArrayList<>();
        String sql = "SELECT de.*, w.name as worker_name FROM daily_evaluation de " +
                    "JOIN worker w ON de.worker_id = w.id ORDER BY de.evaluation_date DESC";
        
        try (Connection conn = DatabaseHelper.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                DailyEvaluation evaluation = new DailyEvaluation();
                evaluation.setId(rs.getInt("id"));
                evaluation.setWorkerId(rs.getInt("worker_id"));
                evaluation.setWorkerName(rs.getString("worker_name"));
                evaluation.setEvaluationDate(LocalDate.parse(rs.getString("evaluation_date")));
                evaluation.setEvaluator(rs.getString("evaluator"));
                evaluation.setProductivityScore(rs.getDouble("productivity_score"));
                evaluation.setQualityScore(rs.getDouble("quality_score"));
                evaluation.setAttendanceScore(rs.getDouble("attendance_score"));
                evaluation.setTeamworkScore(rs.getDouble("teamwork_score"));
                evaluation.setOverallScore(rs.getDouble("overall_score"));
                evaluation.setWorkCompleted(rs.getString("work_completed"));
                evaluation.setChallenges(rs.getString("challenges"));
                evaluation.setImprovements(rs.getString("improvements"));
                evaluation.setComments(rs.getString("comments"));
                evaluation.setStatus(rs.getString("status"));
                evaluation.setLocked(rs.getInt("is_locked") == 1);
                evaluations.add(evaluation);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching daily evaluations: " + e.getMessage());
        }
        return evaluations;
    }

    public static List<DailyEvaluation> getDailyEvaluationsByDateRange(LocalDate startDate, LocalDate endDate) {
        List<DailyEvaluation> evaluations = new ArrayList<>();
        String sql = "SELECT de.*, w.name as worker_name FROM daily_evaluation de " +
                    "JOIN worker w ON de.worker_id = w.id " +
                    "WHERE de.evaluation_date BETWEEN ? AND ? ORDER BY de.evaluation_date DESC";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, startDate.toString());
            pstmt.setString(2, endDate.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                DailyEvaluation evaluation = new DailyEvaluation();
                evaluation.setId(rs.getInt("id"));
                evaluation.setWorkerId(rs.getInt("worker_id"));
                evaluation.setWorkerName(rs.getString("worker_name"));
                evaluation.setEvaluationDate(LocalDate.parse(rs.getString("evaluation_date")));
                evaluation.setEvaluator(rs.getString("evaluator"));
                evaluation.setProductivityScore(rs.getDouble("productivity_score"));
                evaluation.setQualityScore(rs.getDouble("quality_score"));
                evaluation.setAttendanceScore(rs.getDouble("attendance_score"));
                evaluation.setTeamworkScore(rs.getDouble("teamwork_score"));
                evaluation.setOverallScore(rs.getDouble("overall_score"));
                evaluation.setWorkCompleted(rs.getString("work_completed"));
                evaluation.setChallenges(rs.getString("challenges"));
                evaluation.setImprovements(rs.getString("improvements"));
                evaluation.setComments(rs.getString("comments"));
                evaluation.setStatus(rs.getString("status"));
                evaluation.setLocked(rs.getInt("is_locked") == 1);
                evaluations.add(evaluation);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching daily evaluations by date range: " + e.getMessage());
        }
        return evaluations;
    }

    public static List<DailyEvaluation> getDailyEvaluationsByWorker(int workerId) {
        List<DailyEvaluation> evaluations = new ArrayList<>();
        String sql = "SELECT de.*, w.name as worker_name FROM daily_evaluation de " +
                    "JOIN worker w ON de.worker_id = w.id " +
                    "WHERE de.worker_id = ? ORDER BY de.evaluation_date DESC";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, workerId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                DailyEvaluation evaluation = new DailyEvaluation();
                evaluation.setId(rs.getInt("id"));
                evaluation.setWorkerId(rs.getInt("worker_id"));
                evaluation.setWorkerName(rs.getString("worker_name"));
                evaluation.setEvaluationDate(LocalDate.parse(rs.getString("evaluation_date")));
                evaluation.setEvaluator(rs.getString("evaluator"));
                evaluation.setProductivityScore(rs.getDouble("productivity_score"));
                evaluation.setQualityScore(rs.getDouble("quality_score"));
                evaluation.setAttendanceScore(rs.getDouble("attendance_score"));
                evaluation.setTeamworkScore(rs.getDouble("teamwork_score"));
                evaluation.setOverallScore(rs.getDouble("overall_score"));
                evaluation.setWorkCompleted(rs.getString("work_completed"));
                evaluation.setChallenges(rs.getString("challenges"));
                evaluation.setImprovements(rs.getString("improvements"));
                evaluation.setComments(rs.getString("comments"));
                evaluation.setStatus(rs.getString("status"));
                evaluation.setLocked(rs.getInt("is_locked") == 1);
                evaluations.add(evaluation);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching daily evaluations by worker: " + e.getMessage());
        }
        return evaluations;
    }

    public static DailyEvaluation getDailyEvaluationById(int id) {
        String sql = "SELECT de.*, w.name as worker_name FROM daily_evaluation de " +
                    "JOIN worker w ON de.worker_id = w.id WHERE de.id=?";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                DailyEvaluation evaluation = new DailyEvaluation();
                evaluation.setId(rs.getInt("id"));
                evaluation.setWorkerId(rs.getInt("worker_id"));
                evaluation.setWorkerName(rs.getString("worker_name"));
                evaluation.setEvaluationDate(LocalDate.parse(rs.getString("evaluation_date")));
                evaluation.setEvaluator(rs.getString("evaluator"));
                evaluation.setProductivityScore(rs.getDouble("productivity_score"));
                evaluation.setQualityScore(rs.getDouble("quality_score"));
                evaluation.setAttendanceScore(rs.getDouble("attendance_score"));
                evaluation.setTeamworkScore(rs.getDouble("teamwork_score"));
                evaluation.setOverallScore(rs.getDouble("overall_score"));
                evaluation.setWorkCompleted(rs.getString("work_completed"));
                evaluation.setChallenges(rs.getString("challenges"));
                evaluation.setImprovements(rs.getString("improvements"));
                evaluation.setComments(rs.getString("comments"));
                evaluation.setStatus(rs.getString("status"));
                evaluation.setLocked(rs.getInt("is_locked") == 1);
                return evaluation;
            }
        } catch (SQLException e) {
            System.out.println("Error fetching daily evaluation by ID: " + e.getMessage());
        }
        return null;
    }
} 