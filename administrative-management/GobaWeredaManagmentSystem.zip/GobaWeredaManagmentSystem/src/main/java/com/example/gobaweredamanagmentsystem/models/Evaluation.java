package com.example.gobaweredamanagmentsystem.models;

public class Evaluation {
    private int id;
    private int workerId;
    private String evaluator;
    private String date;      // Format: YYYY-MM-DD
    private double score;
    private String comments;
    private String workerName; // For display

    public Evaluation() {}

    public Evaluation(int workerId, String evaluator, String date, double score, String comments) {
        this.workerId = workerId;
        this.evaluator = evaluator;
        this.date = date;
        this.score = score;
        this.comments = comments;
    }

    public Evaluation(int id, int workerId, String evaluator, String date, double score, String comments) {
        this.id = id;
        this.workerId = workerId;
        this.evaluator = evaluator;
        this.date = date;
        this.score = score;
        this.comments = comments;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getWorkerId() { return workerId; }
    public void setWorkerId(int workerId) { this.workerId = workerId; }

    public String getEvaluator() { return evaluator; }
    public void setEvaluator(String evaluator) { this.evaluator = evaluator; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public double getScore() { return score; }
    public void setScore(double score) { this.score = score; }

    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }

    public String getWorkerName() { return workerName; }
    public void setWorkerName(String workerName) { this.workerName = workerName; }
}