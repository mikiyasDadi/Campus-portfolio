package com.example.gobaweredamanagmentsystem.dao;

import com.example.gobaweredamanagmentsystem.models.Report;
import com.example.gobaweredamanagmentsystem.utils.DatabaseHelper;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReportDAO {

    public static boolean addReport(Report report) {
        String sql = "INSERT INTO report (report_type, start_date, end_date, generated_by, " +
                    "generated_date, status, is_locked, total_workers, total_evaluations, " +
                    "average_overall_score, average_productivity_score, average_quality_score, " +
                    "average_attendance_score, average_teamwork_score, summary, recommendations, " +
                    "challenges, achievements) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, report.getReportType());
            pstmt.setString(2, report.getStartDate().toString());
            pstmt.setString(3, report.getEndDate().toString());
            pstmt.setString(4, report.getGeneratedBy());
            pstmt.setString(5, report.getGeneratedDate().toString());
            pstmt.setString(6, report.getStatus());
            pstmt.setInt(7, report.isLocked() ? 1 : 0);
            pstmt.setInt(8, report.getTotalWorkers());
            pstmt.setInt(9, report.getTotalEvaluations());
            pstmt.setDouble(10, report.getAverageOverallScore());
            pstmt.setDouble(11, report.getAverageProductivityScore());
            pstmt.setDouble(12, report.getAverageQualityScore());
            pstmt.setDouble(13, report.getAverageAttendanceScore());
            pstmt.setDouble(14, report.getAverageTeamworkScore());
            pstmt.setString(15, report.getSummary());
            pstmt.setString(16, report.getRecommendations());
            pstmt.setString(17, report.getChallenges());
            pstmt.setString(18, report.getAchievements());
            
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error adding report: " + e.getMessage());
            return false;
        }
    }

    public static boolean updateReport(Report report) {
        // Check if report is locked
        if (isReportLocked(report.getId())) {
            System.out.println("Cannot update locked report");
            return false;
        }

        String sql = "UPDATE report SET report_type=?, start_date=?, end_date=?, generated_by=?, " +
                    "generated_date=?, status=?, total_workers=?, total_evaluations=?, " +
                    "average_overall_score=?, average_productivity_score=?, average_quality_score=?, " +
                    "average_attendance_score=?, average_teamwork_score=?, summary=?, recommendations=?, " +
                    "challenges=?, achievements=? WHERE id=?";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, report.getReportType());
            pstmt.setString(2, report.getStartDate().toString());
            pstmt.setString(3, report.getEndDate().toString());
            pstmt.setString(4, report.getGeneratedBy());
            pstmt.setString(5, report.getGeneratedDate().toString());
            pstmt.setString(6, report.getStatus());
            pstmt.setInt(7, report.getTotalWorkers());
            pstmt.setInt(8, report.getTotalEvaluations());
            pstmt.setDouble(9, report.getAverageOverallScore());
            pstmt.setDouble(10, report.getAverageProductivityScore());
            pstmt.setDouble(11, report.getAverageQualityScore());
            pstmt.setDouble(12, report.getAverageAttendanceScore());
            pstmt.setDouble(13, report.getAverageTeamworkScore());
            pstmt.setString(14, report.getSummary());
            pstmt.setString(15, report.getRecommendations());
            pstmt.setString(16, report.getChallenges());
            pstmt.setString(17, report.getAchievements());
            pstmt.setInt(18, report.getId());
            
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error updating report: " + e.getMessage());
            return false;
        }
    }

    public static boolean deleteReport(int id) {
        // Check if report is locked
        if (isReportLocked(id)) {
            System.out.println("Cannot delete locked report");
            return false;
        }

        String sql = "DELETE FROM report WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error deleting report: " + e.getMessage());
            return false;
        }
    }

    public static boolean lockReport(int id) {
        String sql = "UPDATE report SET is_locked=1, status='Final' WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error locking report: " + e.getMessage());
            return false;
        }
    }

    public static boolean isReportLocked(int id) {
        String sql = "SELECT is_locked FROM report WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("is_locked") == 1;
            }
        } catch (SQLException e) {
            System.out.println("Error checking report lock status: " + e.getMessage());
        }
        return false;
    }

    public static List<Report> getAllReports() {
        List<Report> reports = new ArrayList<>();
        String sql = "SELECT * FROM report ORDER BY generated_date DESC";
        
        try (Connection conn = DatabaseHelper.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Report report = new Report();
                report.setId(rs.getInt("id"));
                report.setReportType(rs.getString("report_type"));
                report.setStartDate(LocalDate.parse(rs.getString("start_date")));
                report.setEndDate(LocalDate.parse(rs.getString("end_date")));
                report.setGeneratedBy(rs.getString("generated_by"));
                report.setGeneratedDate(LocalDate.parse(rs.getString("generated_date")));
                report.setStatus(rs.getString("status"));
                report.setLocked(rs.getInt("is_locked") == 1);
                report.setTotalWorkers(rs.getInt("total_workers"));
                report.setTotalEvaluations(rs.getInt("total_evaluations"));
                report.setAverageOverallScore(rs.getDouble("average_overall_score"));
                report.setAverageProductivityScore(rs.getDouble("average_productivity_score"));
                report.setAverageQualityScore(rs.getDouble("average_quality_score"));
                report.setAverageAttendanceScore(rs.getDouble("average_attendance_score"));
                report.setAverageTeamworkScore(rs.getDouble("average_teamwork_score"));
                report.setSummary(rs.getString("summary"));
                report.setRecommendations(rs.getString("recommendations"));
                report.setChallenges(rs.getString("challenges"));
                report.setAchievements(rs.getString("achievements"));
                reports.add(report);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching reports: " + e.getMessage());
        }
        return reports;
    }

    public static List<Report> getReportsByType(String reportType) {
        List<Report> reports = new ArrayList<>();
        String sql = "SELECT * FROM report WHERE report_type=? ORDER BY generated_date DESC";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, reportType);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Report report = new Report();
                report.setId(rs.getInt("id"));
                report.setReportType(rs.getString("report_type"));
                report.setStartDate(LocalDate.parse(rs.getString("start_date")));
                report.setEndDate(LocalDate.parse(rs.getString("end_date")));
                report.setGeneratedBy(rs.getString("generated_by"));
                report.setGeneratedDate(LocalDate.parse(rs.getString("generated_date")));
                report.setStatus(rs.getString("status"));
                report.setLocked(rs.getInt("is_locked") == 1);
                report.setTotalWorkers(rs.getInt("total_workers"));
                report.setTotalEvaluations(rs.getInt("total_evaluations"));
                report.setAverageOverallScore(rs.getDouble("average_overall_score"));
                report.setAverageProductivityScore(rs.getDouble("average_productivity_score"));
                report.setAverageQualityScore(rs.getDouble("average_quality_score"));
                report.setAverageAttendanceScore(rs.getDouble("average_attendance_score"));
                report.setAverageTeamworkScore(rs.getDouble("average_teamwork_score"));
                report.setSummary(rs.getString("summary"));
                report.setRecommendations(rs.getString("recommendations"));
                report.setChallenges(rs.getString("challenges"));
                report.setAchievements(rs.getString("achievements"));
                reports.add(report);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching reports by type: " + e.getMessage());
        }
        return reports;
    }

    public static Report getReportById(int id) {
        String sql = "SELECT * FROM report WHERE id=?";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                Report report = new Report();
                report.setId(rs.getInt("id"));
                report.setReportType(rs.getString("report_type"));
                report.setStartDate(LocalDate.parse(rs.getString("start_date")));
                report.setEndDate(LocalDate.parse(rs.getString("end_date")));
                report.setGeneratedBy(rs.getString("generated_by"));
                report.setGeneratedDate(LocalDate.parse(rs.getString("generated_date")));
                report.setStatus(rs.getString("status"));
                report.setLocked(rs.getInt("is_locked") == 1);
                report.setTotalWorkers(rs.getInt("total_workers"));
                report.setTotalEvaluations(rs.getInt("total_evaluations"));
                report.setAverageOverallScore(rs.getDouble("average_overall_score"));
                report.setAverageProductivityScore(rs.getDouble("average_productivity_score"));
                report.setAverageQualityScore(rs.getDouble("average_quality_score"));
                report.setAverageAttendanceScore(rs.getDouble("average_attendance_score"));
                report.setAverageTeamworkScore(rs.getDouble("average_teamwork_score"));
                report.setSummary(rs.getString("summary"));
                report.setRecommendations(rs.getString("recommendations"));
                report.setChallenges(rs.getString("challenges"));
                report.setAchievements(rs.getString("achievements"));
                return report;
            }
        } catch (SQLException e) {
            System.out.println("Error fetching report by ID: " + e.getMessage());
        }
        return null;
    }

    public static List<Report> getReportsByDateRange(LocalDate startDate, LocalDate endDate) {
        List<Report> reports = new ArrayList<>();
        String sql = "SELECT * FROM report WHERE start_date >= ? AND end_date <= ? ORDER BY generated_date DESC";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, startDate.toString());
            pstmt.setString(2, endDate.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Report report = new Report();
                report.setId(rs.getInt("id"));
                report.setReportType(rs.getString("report_type"));
                report.setStartDate(LocalDate.parse(rs.getString("start_date")));
                report.setEndDate(LocalDate.parse(rs.getString("end_date")));
                report.setGeneratedBy(rs.getString("generated_by"));
                report.setGeneratedDate(LocalDate.parse(rs.getString("generated_date")));
                report.setStatus(rs.getString("status"));
                report.setLocked(rs.getInt("is_locked") == 1);
                report.setTotalWorkers(rs.getInt("total_workers"));
                report.setTotalEvaluations(rs.getInt("total_evaluations"));
                report.setAverageOverallScore(rs.getDouble("average_overall_score"));
                report.setAverageProductivityScore(rs.getDouble("average_productivity_score"));
                report.setAverageQualityScore(rs.getDouble("average_quality_score"));
                report.setAverageAttendanceScore(rs.getDouble("average_attendance_score"));
                report.setAverageTeamworkScore(rs.getDouble("average_teamwork_score"));
                report.setSummary(rs.getString("summary"));
                report.setRecommendations(rs.getString("recommendations"));
                report.setChallenges(rs.getString("challenges"));
                report.setAchievements(rs.getString("achievements"));
                reports.add(report);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching reports by date range: " + e.getMessage());
        }
        return reports;
    }
} 