package com.example.gobaweredamanagmentsystem.controllers;

import com.example.gobaweredamanagmentsystem.dao.EvaluationDAO;
import com.example.gobaweredamanagmentsystem.dao.WorkerDAO;
import com.example.gobaweredamanagmentsystem.models.Evaluation;
import com.example.gobaweredamanagmentsystem.models.Worker;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import java.util.List;

public class EvaluationController {

    @FXML private TextField searchField;
    @FXML private TableView<Evaluation> evaluationTable;
    @FXML private TableColumn<Evaluation, Integer> idCol;
    @FXML private TableColumn<Evaluation, String> workerNameCol;
    @FXML private TableColumn<Evaluation, String> evaluatorCol;
    @FXML private TableColumn<Evaluation, String> dateCol;
    @FXML private TableColumn<Evaluation, Double> scoreCol;
    @FXML private TableColumn<Evaluation, String> commentsCol;

    @FXML private ComboBox<Worker> workerComboBox;
    @FXML private TextField evaluatorField;
    @FXML private TextField dateField;
    @FXML private TextField scoreField;
    @FXML private TextField commentsField;
    @FXML private Text statusText;

    private ObservableList<Evaluation> evaluationList = FXCollections.observableArrayList();
    private ObservableList<Worker> workerList = FXCollections.observableArrayList();
    private FilteredList<Evaluation> filteredData;
    private SortedList<Evaluation> sortedData;
    @FXML
    public void initialize() {
        setupTableColumns();
        setupComboBoxes();
        loadData();

        filteredData = new FilteredList<>(evaluationList, p -> true);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filteredData.setPredicate(eval -> {
                if (newVal == null || newVal.isEmpty()) return true;
                String filter = newVal.toLowerCase();
                return (eval.getWorkerName() != null && eval.getWorkerName().toLowerCase().contains(filter))
                        || (eval.getEvaluator() != null && eval.getEvaluator().toLowerCase().contains(filter))
                        || (eval.getDate() != null && eval.getDate().toLowerCase().contains(filter));
            });
        });
        sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(evaluationTable.comparatorProperty());
        evaluationTable.setItems(sortedData);

        setupTableSelection();
    }



    private void setupTableColumns() {
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        workerNameCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getWorkerName()));
        evaluatorCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getEvaluator()));
        dateCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDate()));
        scoreCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleDoubleProperty(cellData.getValue().getScore()).asObject());
        commentsCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getComments()));
    }

    private void setupComboBoxes() {
        workerList.setAll(WorkerDAO.getAllWorkers());
        workerComboBox.setItems(workerList);
        workerComboBox.setCellFactory(param -> new ListCell<Worker>() {
            @Override
            protected void updateItem(Worker item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getName() + " (ID: " + item.getId() + ")");
                }
            }
        });
        workerComboBox.setButtonCell(workerComboBox.getCellFactory().call(null));
    }

    private void loadData() {
        evaluationList.setAll(EvaluationDAO.getAllEvaluations());
        evaluationTable.setItems(evaluationList);
        statusText.setText("Loaded " + evaluationList.size() + " evaluation records");
    }

    private void setupTableSelection() {
        evaluationTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                // Find and select the worker
                for (Worker worker : workerList) {
                    if (worker.getId() == newSel.getWorkerId()) {
                        workerComboBox.setValue(worker);
                        break;
                    }
                }
                evaluatorField.setText(newSel.getEvaluator());
                dateField.setText(newSel.getDate());
                scoreField.setText(String.valueOf(newSel.getScore()));
                commentsField.setText(newSel.getComments() != null ? newSel.getComments() : "");
            }
        });
    }

    @FXML
    private void handleAdd() {
        if (!validateForm()) return;

        double score;
        try {
            score = Double.parseDouble(scoreField.getText().trim());
        } catch (NumberFormatException e) {
            showAlert("Validation Error", "Score must be a number.");
            return;
        }

        Evaluation evaluation = new Evaluation(
                workerComboBox.getValue().getId(),
                evaluatorField.getText().trim(),
                dateField.getText().trim(),
                score,
                commentsField.getText().trim()
        );

        if (EvaluationDAO.addEvaluation(evaluation)) {
            loadData();
            clearForm();
            showAlert("Success", "Evaluation added successfully!");
        } else {
            showAlert("Error", "Could not add evaluation.");
        }
    }

    @FXML
    private void handleEdit() {
        Evaluation selected = evaluationTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a record to edit.");
            return;
        }

        if (!validateForm()) return;

        double score;
        try {
            score = Double.parseDouble(scoreField.getText().trim());
        } catch (NumberFormatException e) {
            showAlert("Validation Error", "Score must be a number.");
            return;
        }

        selected.setWorkerId(workerComboBox.getValue().getId());
        selected.setEvaluator(evaluatorField.getText().trim());
        selected.setDate(dateField.getText().trim());
        selected.setScore(score);
        selected.setComments(commentsField.getText().trim());

        if (EvaluationDAO.updateEvaluation(selected)) {
            loadData();
            clearForm();
            showAlert("Success", "Evaluation updated successfully!");
        } else {
            showAlert("Error", "Could not update evaluation.");
        }
    }

    @FXML
    private void handleDelete() {
        Evaluation selected = evaluationTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a record to delete.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Delete");
        alert.setHeaderText("Delete Evaluation Record");
        alert.setContentText("Are you sure you want to delete this record?");

        if (alert.showAndWait().orElse(null) == ButtonType.OK) {
            if (EvaluationDAO.deleteEvaluation(selected.getId())) {
                loadData();
                clearForm();
                showAlert("Success", "Evaluation deleted successfully!");
            } else {
                showAlert("Error", "Could not delete evaluation.");
            }
        }
    }

    @FXML
    private void handleClear() {
        clearForm();
    }

    private boolean validateForm() {
        if (workerComboBox.getValue() == null) {
            showAlert("Validation Error", "Please select a worker.");
            return false;
        }
        if (evaluatorField.getText().trim().isEmpty()) {
            showAlert("Validation Error", "Please enter evaluator name.");
            return false;
        }
        if (dateField.getText().trim().isEmpty()) {
            showAlert("Validation Error", "Please enter a date.");
            return false;
        }
        if (scoreField.getText().trim().isEmpty()) {
            showAlert("Validation Error", "Please enter a score.");
            return false;
        }
        return true;
    }

    private void clearForm() {
        workerComboBox.setValue(null);
        evaluatorField.clear();
        dateField.clear();
        scoreField.clear();
        commentsField.clear();
        evaluationTable.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}