package com.example.gobaweredamanagmentsystem.controllers;

import com.example.gobaweredamanagmentsystem.dao.*;
import com.example.gobaweredamanagmentsystem.models.*;
import com.example.gobaweredamanagmentsystem.utils.ReportGenerator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.control.Label;

import java.io.FileWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;

public class ReportsController {

    @FXML private TextField searchField;
    @FXML private ComboBox<String> reportTypeComboBox;
    @FXML private TableView reportTable;
    @FXML private Text statusText;
    
    // New reporting controls
    @FXML private ComboBox<String> evaluationReportTypeComboBox;
    @FXML private DatePicker startDatePicker;
    @FXML private DatePicker endDatePicker;
    @FXML private Button generateReportButton;
    @FXML private Button exportReportButton;
    @FXML private Button lockReportButton;
    @FXML private VBox reportSummaryBox;
    @FXML private Label totalWorkersLabel;
    @FXML private Label totalEvaluationsLabel;
    @FXML private Label averageScoreLabel;
    @FXML private Label topPerformersLabel;
    @FXML private TextArea recommendationsArea;
    @FXML private TextArea challengesArea;
    @FXML private TextArea achievementsArea;

    private Report currentReport;
    private List<DailyEvaluation> currentEvaluations;

    @FXML
    public void initialize() {
        setupReportTypeComboBoxes();
        setupDatePickers();
        setupSearchAndSort();
        setupReportSummaryBox();
    }

    private void setupReportTypeComboBoxes() {
        // Legacy report types
        reportTypeComboBox.setItems(FXCollections.observableArrayList(
                "Worker List",
                "Job List",
                "Job Assignments",
                "Attendance Records",
                "Evaluations"
        ));

        // New evaluation report types
        evaluationReportTypeComboBox.setItems(FXCollections.observableArrayList(
                "Daily Evaluations",
                "Weekly Report",
                "Monthly Report",
                "Quarterly Report",
                "Annual Report"
        ));
    }

    private void setupDatePickers() {
        startDatePicker.setValue(LocalDate.now().minusWeeks(1));
        endDatePicker.setValue(LocalDate.now());
    }

    private void setupSearchAndSort() {
        FilteredList filteredData = new FilteredList<>(reportTable.getItems(), p -> true);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filteredData.setPredicate(item -> {
                if (newVal == null || newVal.isEmpty()) return true;
                String filter = newVal.toLowerCase();
                return item.toString().toLowerCase().contains(filter);
            });
        });

        SortedList<Object> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(reportTable.comparatorProperty());
        reportTable.setItems(sortedData);
    }

    private void setupReportSummaryBox() {
        reportSummaryBox.setVisible(false);
    }

    @FXML
    private void handleLoadReport() {
        String type = reportTypeComboBox.getValue();
        if (type == null) {
            statusText.setText("Please select a report type.");
            return;
        }
        switch (type) {
            case "Worker List" -> loadWorkerReport();
            case "Job List" -> loadJobReport();
            case "Job Assignments" -> loadJobAssignmentReport();
            case "Attendance Records" -> loadAttendanceReport();
            case "Evaluations" -> loadEvaluationReport();
        }
    }

    private void loadWorkerReport() {
        List<Worker> workers = WorkerDAO.getAllWorkers();
        TableView<Worker> table = new TableView<>();
        TableColumn<Worker, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        TableColumn<Worker, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getName()));
        TableColumn<Worker, String> genderCol = new TableColumn<>("Gender");
        genderCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getGender()));
        TableColumn<Worker, String> contactCol = new TableColumn<>("Contact");
        contactCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getContact()));
        table.getColumns().addAll(idCol, nameCol, genderCol, contactCol);
        table.setItems(FXCollections.observableArrayList(workers));
        reportTable.getColumns().setAll(table.getColumns());
        reportTable.setItems(table.getItems());
        statusText.setText("Loaded Worker List");
    }

    private void loadJobReport() {
        List<Job> jobs = JobDAO.getAllJobs();
        TableView<Job> table = new TableView<>();
        TableColumn<Job, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        TableColumn<Job, String> titleCol = new TableColumn<>("Title");
        titleCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getTitle()));
        TableColumn<Job, String> deptCol = new TableColumn<>("Department");
        deptCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDepartment()));
        TableColumn<Job, Double> salaryCol = new TableColumn<>("Salary");
        salaryCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleDoubleProperty(cellData.getValue().getSalary()).asObject());
        table.getColumns().addAll(idCol, titleCol, deptCol, salaryCol);
        table.setItems(FXCollections.observableArrayList(jobs));
        reportTable.getColumns().setAll(table.getColumns());
        reportTable.setItems(table.getItems());
        statusText.setText("Loaded Job List");
    }

    private void loadJobAssignmentReport() {
        List<JobAssignment> assignments = JobAssignmentDAO.getAllJobAssignments();
        TableView<JobAssignment> table = new TableView<>();
        TableColumn<JobAssignment, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        TableColumn<JobAssignment, String> workerCol = new TableColumn<>("Worker");
        workerCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getWorkerName()));
        TableColumn<JobAssignment, String> jobCol = new TableColumn<>("Job");
        jobCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getJobTitle()));
        TableColumn<JobAssignment, String> startCol = new TableColumn<>("Start Date");
        startCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStartDate()));
        TableColumn<JobAssignment, String> endCol = new TableColumn<>("End Date");
        endCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getEndDate()));
        TableColumn<JobAssignment, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));
        table.getColumns().addAll(idCol, workerCol, jobCol, startCol, endCol, statusCol);
        table.setItems(FXCollections.observableArrayList(assignments));
        reportTable.getColumns().setAll(table.getColumns());
        reportTable.setItems(table.getItems());
        statusText.setText("Loaded Job Assignments");
    }

    private void loadAttendanceReport() {
        List<Attendance> attendance = AttendanceDAO.getAllAttendance();
        TableView<Attendance> table = new TableView<>();
        TableColumn<Attendance, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        TableColumn<Attendance, String> workerCol = new TableColumn<>("Worker");
        workerCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getWorkerName()));
        TableColumn<Attendance, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDate()));
        TableColumn<Attendance, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));
        table.getColumns().addAll(idCol, workerCol, dateCol, statusCol);
        table.setItems(FXCollections.observableArrayList(attendance));
        reportTable.getColumns().setAll(table.getColumns());
        reportTable.setItems(table.getItems());
        statusText.setText("Loaded Attendance Records");
    }

    private void loadEvaluationReport() {
        List<Evaluation> evaluations = EvaluationDAO.getAllEvaluations();
        TableView<Evaluation> table = new TableView<>();
        TableColumn<Evaluation, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        TableColumn<Evaluation, String> workerCol = new TableColumn<>("Worker");
        workerCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getWorkerName()));
        TableColumn<Evaluation, String> evaluatorCol = new TableColumn<>("Evaluator");
        evaluatorCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getEvaluator()));
        TableColumn<Evaluation, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDate()));
        TableColumn<Evaluation, Double> scoreCol = new TableColumn<>("Score");
        scoreCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleDoubleProperty(cellData.getValue().getScore()).asObject());
        table.getColumns().addAll(idCol, workerCol, evaluatorCol, dateCol, scoreCol);
        table.setItems(FXCollections.observableArrayList(evaluations));
        reportTable.getColumns().setAll(table.getColumns());
        reportTable.setItems(table.getItems());
        statusText.setText("Loaded Evaluations");
    }

    @FXML
    private void handleExport() {
        String type = reportTypeComboBox.getValue();
        if (type == null) {
            statusText.setText("Please select a report type.");
            return;
        }
        try {
            FileWriter writer = new FileWriter(type.replace(" ", "_") + ".csv");
            ObservableList<TableColumn> columns = reportTable.getColumns();
            // Write header
            for (int i = 0; i < columns.size(); i++) {
                writer.write(columns.get(i).getText());
                if (i < columns.size() - 1) writer.write(",");
            }
            writer.write("\n");
            // Write rows
            for (Object item : reportTable.getItems()) {
                for (int i = 0; i < columns.size(); i++) {
                    TableColumn col = columns.get(i);
                    Object cellData = col.getCellObservableValue(item).getValue();
                    writer.write(cellData != null ? cellData.toString() : "");
                    if (i < columns.size() - 1) writer.write(",");
                }
                writer.write("\n");
            }
            writer.close();
            statusText.setText("Exported to " + type.replace(" ", "_") + ".csv");
        } catch (Exception e) {
            e.printStackTrace();
            statusText.setText("Export failed: " + e.getMessage());
        }
    }

    // New evaluation reporting methods
    @FXML
    private void handleGenerateEvaluationReport() {
        String reportType = evaluationReportTypeComboBox.getValue();
        LocalDate startDate = startDatePicker.getValue();
        LocalDate endDate = endDatePicker.getValue();

        if (reportType == null) {
            showAlert("Error", "Please select a report type.");
            return;
        }

        if (startDate == null || endDate == null) {
            showAlert("Error", "Please select start and end dates.");
            return;
        }

        if (startDate.isAfter(endDate)) {
            showAlert("Error", "Start date cannot be after end date.");
            return;
        }

        try {
            switch (reportType) {
                case "Daily Evaluations":
                    generateDailyEvaluationsReport(startDate, endDate);
                    break;
                case "Weekly Report":
                    generateWeeklyReport(startDate);
                    break;
                case "Monthly Report":
                    generateMonthlyReport(startDate);
                    break;
                case "Quarterly Report":
                    generateQuarterlyReport(startDate);
                    break;
                case "Annual Report":
                    generateAnnualReport(startDate);
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to generate report: " + e.getMessage());
        }
    }

    private void generateDailyEvaluationsReport(LocalDate startDate, LocalDate endDate) {
        currentEvaluations = DailyEvaluationDAO.getDailyEvaluationsByDateRange(startDate, endDate);
        displayDailyEvaluationsTable(currentEvaluations);
        statusText.setText("Generated daily evaluations report for " + startDate + " to " + endDate);
    }

    private void generateWeeklyReport(LocalDate weekStart) {
        currentReport = ReportGenerator.generateWeeklyReport(weekStart, "System User");
        currentEvaluations = DailyEvaluationDAO.getDailyEvaluationsByDateRange(weekStart, weekStart.plusDays(6));
        displayReportSummary(currentReport);
        statusText.setText("Generated weekly report for week starting " + weekStart);
    }

    private void generateMonthlyReport(LocalDate monthStart) {
        currentReport = ReportGenerator.generateMonthlyReport(monthStart, "System User");
        currentEvaluations = DailyEvaluationDAO.getDailyEvaluationsByDateRange(monthStart, monthStart.plusMonths(1).minusDays(1));
        displayReportSummary(currentReport);
        statusText.setText("Generated monthly report for " + monthStart.format(DateTimeFormatter.ofPattern("MMMM yyyy")));
    }

    private void generateQuarterlyReport(LocalDate quarterStart) {
        currentReport = ReportGenerator.generateQuarterlyReport(quarterStart, "System User");
        currentEvaluations = DailyEvaluationDAO.getDailyEvaluationsByDateRange(quarterStart, quarterStart.plusMonths(3).minusDays(1));
        displayReportSummary(currentReport);
        statusText.setText("Generated quarterly report for quarter starting " + quarterStart);
    }

    private void generateAnnualReport(LocalDate yearStart) {
        currentReport = ReportGenerator.generateAnnualReport(yearStart, "System User");
        currentEvaluations = DailyEvaluationDAO.getDailyEvaluationsByDateRange(yearStart, yearStart.plusYears(1).minusDays(1));
        displayReportSummary(currentReport);
        statusText.setText("Generated annual report for " + yearStart.getYear());
    }

    private void displayDailyEvaluationsTable(List<DailyEvaluation> evaluations) {
        // Clear existing table
        reportTable.getColumns().clear();
        reportTable.getItems().clear();

        // Create table columns
        TableColumn<DailyEvaluation, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());

        TableColumn<DailyEvaluation, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(
                cellData.getValue().getEvaluationDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))));

        TableColumn<DailyEvaluation, String> workerCol = new TableColumn<>("Worker");
        workerCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getWorkerName()));

        TableColumn<DailyEvaluation, String> evaluatorCol = new TableColumn<>("Evaluator");
        evaluatorCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getEvaluator()));

        TableColumn<DailyEvaluation, Double> overallCol = new TableColumn<>("Overall Score");
        overallCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleDoubleProperty(cellData.getValue().getOverallScore()).asObject());

        TableColumn<DailyEvaluation, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));

        reportTable.getColumns().addAll(idCol, dateCol, workerCol, evaluatorCol, overallCol, statusCol);
        reportTable.setItems(FXCollections.observableArrayList(evaluations));

        // Hide report summary
        reportSummaryBox.setVisible(false);
    }

    private void displayReportSummary(Report report) {
        // Update summary labels
        totalWorkersLabel.setText("Total Workers: " + report.getTotalWorkers());
        totalEvaluationsLabel.setText("Total Evaluations: " + report.getTotalEvaluations());
        averageScoreLabel.setText(String.format("Average Overall Score: %.2f", report.getAverageOverallScore()));
        
        if (report.getTopPerformers() != null && !report.getTopPerformers().isEmpty()) {
            topPerformersLabel.setText("Top Performers: " + String.join(", ", report.getTopPerformers()));
        } else {
            topPerformersLabel.setText("Top Performers: None");
        }

        // Update text areas
        recommendationsArea.setText(report.getRecommendations() != null ? report.getRecommendations() : "");
        challengesArea.setText(report.getChallenges() != null ? report.getChallenges() : "");
        achievementsArea.setText(report.getAchievements() != null ? report.getAchievements() : "");

        // Show report summary
        reportSummaryBox.setVisible(true);

        // Clear table
        reportTable.getColumns().clear();
        reportTable.getItems().clear();
    }

    @FXML
    private void handleExportEvaluationReport() {
        if (currentReport == null && currentEvaluations == null) {
            showAlert("Error", "No report to export. Please generate a report first.");
            return;
        }

        String filePath = null;
        if (currentReport != null && currentEvaluations != null) {
            filePath = ReportGenerator.exportReportToDesktop(currentReport, currentEvaluations);
        } else if (currentEvaluations != null) {
            filePath = ReportGenerator.exportDailyEvaluationsToDesktop(currentEvaluations, "Custom");
        }

        if (filePath != null) {
            showAlert("Export Success", "Report exported to: " + filePath);
            statusText.setText("Report exported successfully to desktop");
        } else {
            showAlert("Export Error", "Failed to export report.");
            statusText.setText("Export failed");
        }
    }

    @FXML
    private void handleLockReport() {
        if (currentReport == null) {
            showAlert("Error", "No report to lock. Please generate a report first.");
            return;
        }

        if (currentReport.isLocked()) {
            showAlert("Already Locked", "This report is already locked.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Lock Report");
        alert.setHeaderText("Lock Report");
        alert.setContentText("Are you sure you want to lock this report? It cannot be modified after locking.");

        if (alert.showAndWait().orElse(null) == ButtonType.OK) {
            if (ReportDAO.lockReport(currentReport.getId())) {
                currentReport.setLocked(true);
                currentReport.setStatus("Final");
                showAlert("Success", "Report locked successfully!");
                statusText.setText("Report locked successfully");
            } else {
                showAlert("Error", "Failed to lock report.");
            }
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}