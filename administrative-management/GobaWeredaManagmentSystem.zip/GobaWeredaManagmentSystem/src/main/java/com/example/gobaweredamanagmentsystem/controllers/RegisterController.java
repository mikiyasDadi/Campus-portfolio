package com.example.gobaweredamanagmentsystem.controllers;

import com.example.gobaweredamanagmentsystem.dao.UserDAO;
import com.example.gobaweredamanagmentsystem.models.User;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.collections.FXCollections;

public class RegisterController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private ComboBox<String> roleComboBox;
    @FXML private Text errorText;

    @FXML
    public void initialize() {
        roleComboBox.setItems(FXCollections.observableArrayList("admin", "manager", "user"));
    }

    @FXML
    private void handleRegister() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String confirmPassword = confirmPasswordField.getText().trim();
        String role = roleComboBox.getValue();

        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || role == null) {
            errorText.setText("Please fill in all fields.");
            return;
        }
        if (!password.equals(confirmPassword)) {
            errorText.setText("Passwords do not match.");
            return;
        }
        if (UserDAO.getUserByUsername(username) != null) {
            errorText.setText("Username already exists.");
            return;
        }
        if (UserDAO.addUser(new User(username, password, role))) {
            errorText.setText("Registration successful! You can now log in.");
        } else {
            errorText.setText("Registration failed. Try again.");
        }
    }

    @FXML
    private void handleBackToLogin() {
        try {
            Stage stage = (Stage) usernameField.getScene().getWindow();
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/gobaweredamanagmentsystem/login.fxml"));
            stage.setScene(new Scene(root, 400, 350));
            stage.setTitle("Login - Goba Wereda Management System");
        } catch (Exception e) {
            e.printStackTrace();
            errorText.setText("Error loading login screen.");
        }
    }
}