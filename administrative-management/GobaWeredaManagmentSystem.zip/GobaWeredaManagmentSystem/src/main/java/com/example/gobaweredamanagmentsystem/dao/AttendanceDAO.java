package com.example.gobaweredamanagmentsystem.dao;

import com.example.gobaweredamanagmentsystem.models.Attendance;
import com.example.gobaweredamanagmentsystem.utils.DatabaseHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AttendanceDAO {

    public static boolean addAttendance(Attendance attendance) {
        String sql = "INSERT INTO attendance (worker_id, date, status, notes) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, attendance.getWorkerId());
            pstmt.setString(2, attendance.getDate());
            pstmt.setString(3, attendance.getStatus());
            pstmt.setString(4, attendance.getNotes());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error adding attendance: " + e.getMessage());
            return false;
        }
    }

    public static boolean updateAttendance(Attendance attendance) {
        String sql = "UPDATE attendance SET worker_id=?, date=?, status=?, notes=? WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, attendance.getWorkerId());
            pstmt.setString(2, attendance.getDate());
            pstmt.setString(3, attendance.getStatus());
            pstmt.setString(4, attendance.getNotes());
            pstmt.setInt(5, attendance.getId());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error updating attendance: " + e.getMessage());
            return false;
        }
    }

    public static boolean deleteAttendance(int id) {
        String sql = "DELETE FROM attendance WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error deleting attendance: " + e.getMessage());
            return false;
        }
    }

    public static List<Attendance> getAllAttendance() {
        List<Attendance> list = new ArrayList<>();
        String sql = "SELECT a.*, w.name as worker_name FROM attendance a JOIN worker w ON a.worker_id = w.id ORDER BY a.date DESC";
        try (Connection conn = DatabaseHelper.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Attendance att = new Attendance(
                        rs.getInt("id"),
                        rs.getInt("worker_id"),
                        rs.getString("date"),
                        rs.getString("status"),
                        rs.getString("notes")
                );
                att.setWorkerName(rs.getString("worker_name"));
                list.add(att);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching attendance: " + e.getMessage());
        }
        return list;
    }
}