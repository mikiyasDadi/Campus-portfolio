package com.example.gobaweredamanagmentsystem.controllers;

import com.example.gobaweredamanagmentsystem.dao.UserDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.util.Objects;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Text errorText;

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            errorText.setText("Please enter both username and password.");
            return;
        }

        if (UserDAO.validateLogin(username, password)) {
            // Login successful, load dashboard
            try {
                Stage stage = (Stage) usernameField.getScene().getWindow();
                Parent root = FXMLLoader.load(getClass().getResource("/com/example/gobaweredamanagmentsystem/dashboard.fxml"));
                stage.setScene(new Scene(root, 1200, 700));
                stage.setTitle("Goba Wereda Management System");
            } catch (Exception e) {
                e.printStackTrace();
                errorText.setText("Error loading dashboard.");
            }
        } else {
            errorText.setText("Invalid username or password.");
        }
    }
    @FXML
    private void handleRegister() {
        try {
            Stage stage = (Stage) usernameField.getScene().getWindow();
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/gobaweredamanagmentsystem/register.fxml")));            stage.setScene(new Scene(root, 400, 450));
            stage.setTitle("Register - Goba Wereda Management System");
        } catch (Exception e) {
            e.printStackTrace();
            errorText.setText("Error loading registration screen.");
        }
    }}