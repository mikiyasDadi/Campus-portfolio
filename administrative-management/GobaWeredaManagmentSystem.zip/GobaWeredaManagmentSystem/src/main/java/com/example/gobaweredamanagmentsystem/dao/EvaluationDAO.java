package com.example.gobaweredamanagmentsystem.dao;

import com.example.gobaweredamanagmentsystem.models.Evaluation;
import com.example.gobaweredamanagmentsystem.utils.DatabaseHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EvaluationDAO {

    public static boolean addEvaluation(Evaluation evaluation) {
        String sql = "INSERT INTO evaluation (worker_id, evaluator, date, score, comments) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, evaluation.getWorkerId());
            pstmt.setString(2, evaluation.getEvaluator());
            pstmt.setString(3, evaluation.getDate());
            pstmt.setDouble(4, evaluation.getScore());
            pstmt.setString(5, evaluation.getComments());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error adding evaluation: " + e.getMessage());
            return false;
        }
    }

    public static boolean updateEvaluation(Evaluation evaluation) {
        String sql = "UPDATE evaluation SET worker_id=?, evaluator=?, date=?, score=?, comments=? WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, evaluation.getWorkerId());
            pstmt.setString(2, evaluation.getEvaluator());
            pstmt.setString(3, evaluation.getDate());
            pstmt.setDouble(4, evaluation.getScore());
            pstmt.setString(5, evaluation.getComments());
            pstmt.setInt(6, evaluation.getId());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error updating evaluation: " + e.getMessage());
            return false;
        }
    }

    public static boolean deleteEvaluation(int id) {
        String sql = "DELETE FROM evaluation WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error deleting evaluation: " + e.getMessage());
            return false;
        }
    }

    public static List<Evaluation> getAllEvaluations() {
        List<Evaluation> list = new ArrayList<>();
        String sql = "SELECT e.*, w.name as worker_name FROM evaluation e JOIN worker w ON e.worker_id = w.id ORDER BY e.date DESC";
        try (Connection conn = DatabaseHelper.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Evaluation eval = new Evaluation(
                        rs.getInt("id"),
                        rs.getInt("worker_id"),
                        rs.getString("evaluator"),
                        rs.getString("date"),
                        rs.getDouble("score"),
                        rs.getString("comments")
                );
                eval.setWorkerName(rs.getString("worker_name"));
                list.add(eval);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching evaluations: " + e.getMessage());
        }
        return list;
    }
}