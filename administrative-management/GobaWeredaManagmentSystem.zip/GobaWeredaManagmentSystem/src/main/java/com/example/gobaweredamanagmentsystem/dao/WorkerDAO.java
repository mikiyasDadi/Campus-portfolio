package com.example.gobaweredamanagmentsystem.dao;


//
//import models.Worker;
//import utils.DatabaseHelper;

import com.example.gobaweredamanagmentsystem.models.Worker;
import com.example.gobaweredamanagmentsystem.utils.DatabaseHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class WorkerDAO {

    // Add a new worker
    public static boolean addWorker(Worker worker) {
        String sql = "INSERT INTO worker (name, gender, date_of_birth, contact, address, hire_date, position, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, worker.getName());
            pstmt.setString(2, worker.getGender());
            pstmt.setString(3, worker.getDateOfBirth());
            pstmt.setString(4, worker.getContact());
            pstmt.setString(5, worker.getAddress());
            pstmt.setString(6, worker.getHireDate());
            pstmt.setString(7, worker.getPosition());
            pstmt.setString(8, worker.getStatus());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error adding worker: " + e.getMessage());
            return false;
        }
    }

    // Update an existing worker
    public static boolean updateWorker(Worker worker) {
        String sql = "UPDATE worker SET name=?, gender=?, date_of_birth=?, contact=?, address=?, hire_date=?, position=?, status=? WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, worker.getName());
            pstmt.setString(2, worker.getGender());
            pstmt.setString(3, worker.getDateOfBirth());
            pstmt.setString(4, worker.getContact());
            pstmt.setString(5, worker.getAddress());
            pstmt.setString(6, worker.getHireDate());
            pstmt.setString(7, worker.getPosition());
            pstmt.setString(8, worker.getStatus());
            pstmt.setInt(9, worker.getId());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error updating worker: " + e.getMessage());
            return false;
        }
    }

    // Delete a worker by id
    public static boolean deleteWorker(int id) {
        String sql = "DELETE FROM worker WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error deleting worker: " + e.getMessage());
            return false;
        }
    }

    // Get all workers
    public static List<Worker> getAllWorkers() {
        List<Worker> workers = new ArrayList<>();
        String sql = "SELECT * FROM worker";
        try (Connection conn = DatabaseHelper.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Worker worker = new Worker(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("gender"),
                        rs.getString("date_of_birth"),
                        rs.getString("contact"),
                        rs.getString("address"),
                        rs.getString("hire_date"),
                        rs.getString("position"),
                        rs.getString("status")
                );
                workers.add(worker);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching workers: " + e.getMessage());
        }
        return workers;
    }

    // Get a worker by id
    public static Worker getWorkerById(int id) {
        String sql = "SELECT * FROM worker WHERE id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Worker(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("gender"),
                        rs.getString("date_of_birth"),
                        rs.getString("contact"),
                        rs.getString("address"),
                        rs.getString("hire_date"),
                        rs.getString("position"),
                        rs.getString("status")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error fetching worker by id: " + e.getMessage());
        }
        return null;
    }
}
