package com.example.gobaweredamanagmentsystem.controllers;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import com.example.gobaweredamanagmentsystem.dao.AttendanceDAO;
import com.example.gobaweredamanagmentsystem.dao.WorkerDAO;
import com.example.gobaweredamanagmentsystem.models.Attendance;
import com.example.gobaweredamanagmentsystem.models.Worker;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class AttendanceController {

    @FXML private  TextField searchField;
    @FXML private TableView<Attendance> attendanceTable;
    @FXML private TableColumn<Attendance, Integer> idCol;
    @FXML private TableColumn<Attendance, String> workerNameCol;
    @FXML private TableColumn<Attendance, String> dateCol;
    @FXML private TableColumn<Attendance, String> statusCol;
    @FXML private TableColumn<Attendance, String> notesCol;

    @FXML private ComboBox<Worker> workerComboBox;
    @FXML private TextField dateField;
    @FXML private ComboBox<String> statusComboBox;
    @FXML private TextField notesField;
    @FXML private Text statusText;

    private ObservableList<Attendance> attendanceList = FXCollections.observableArrayList();
    private ObservableList<Worker> workerList = FXCollections.observableArrayList();
    private FilteredList<Attendance> filteredData;
    private SortedList<Attendance> sortedData;

    @FXML
    public void initialize() {
        setupTableColumns();
        setupComboBoxes();
        loadData();
        filteredData = new FilteredList<>(attendanceList, p -> true);
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filteredData.setPredicate(att -> {
                if (newVal == null || newVal.isEmpty()) return true;
                String filter = newVal.toLowerCase();
                return (att.getWorkerName() != null && att.getWorkerName().toLowerCase().contains(filter))
                        || (att.getDate() != null && att.getDate().toLowerCase().contains(filter))
                        || (att.getStatus() != null && att.getStatus().toLowerCase().contains(filter));
            });
        });

        sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(attendanceTable.comparatorProperty());
        attendanceTable.setItems(sortedData);



        setupTableSelection();
    }

    private void setupTableColumns() {
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        workerNameCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getWorkerName()));
        dateCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDate()));
        statusCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));
        notesCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getNotes()));
    }

    private void setupComboBoxes() {
        // Status options
        statusComboBox.setItems(FXCollections.observableArrayList("Present", "Absent", "Late", "Excused"));

        // Worker options
        workerList.setAll(WorkerDAO.getAllWorkers());
        workerComboBox.setItems(workerList);
        workerComboBox.setCellFactory(param -> new ListCell<Worker>() {
            @Override
            protected void updateItem(Worker item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getName() + " (ID: " + item.getId() + ")");
                }
            }
        });
        workerComboBox.setButtonCell(workerComboBox.getCellFactory().call(null));
    }

    private void loadData() {
        attendanceList.setAll(AttendanceDAO.getAllAttendance());
        attendanceTable.setItems(attendanceList);
        statusText.setText("Loaded " + attendanceList.size() + " attendance records");
    }

    private void setupTableSelection() {
        attendanceTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                // Find and select the worker
                for (Worker worker : workerList) {
                    if (worker.getId() == newSel.getWorkerId()) {
                        workerComboBox.setValue(worker);
                        break;
                    }
                }
                dateField.setText(newSel.getDate());
                statusComboBox.setValue(newSel.getStatus());
                notesField.setText(newSel.getNotes() != null ? newSel.getNotes() : "");
            }
        });
    }

    @FXML
    private void handleAdd() {
        if (!validateForm()) return;

        Attendance attendance = new Attendance(
                workerComboBox.getValue().getId(),
                dateField.getText().trim(),
                statusComboBox.getValue(),
                notesField.getText().trim()
        );

        if (AttendanceDAO.addAttendance(attendance)) {
            loadData();
            clearForm();
            showAlert("Success", "Attendance added successfully!");
        } else {
            showAlert("Error", "Could not add attendance.");
        }
    }

    @FXML
    private void handleEdit() {
        Attendance selected = attendanceTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a record to edit.");
            return;
        }

        if (!validateForm()) return;

        selected.setWorkerId(workerComboBox.getValue().getId());
        selected.setDate(dateField.getText().trim());
        selected.setStatus(statusComboBox.getValue());
        selected.setNotes(notesField.getText().trim());

        if (AttendanceDAO.updateAttendance(selected)) {
            loadData();
            clearForm();
            showAlert("Success", "Attendance updated successfully!");
        } else {
            showAlert("Error", "Could not update attendance.");
        }
    }

    @FXML
    private void handleDelete() {
        Attendance selected = attendanceTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a record to delete.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Delete");
        alert.setHeaderText("Delete Attendance Record");
        alert.setContentText("Are you sure you want to delete this record?");

        if (alert.showAndWait().orElse(null) == ButtonType.OK) {
            if (AttendanceDAO.deleteAttendance(selected.getId())) {
                loadData();
                clearForm();
                showAlert("Success", "Attendance deleted successfully!");
            } else {
                showAlert("Error", "Could not delete attendance.");
            }
        }
    }

    @FXML
    private void handleClear() {
        clearForm();
    }

    @FXML
    private void handleRefresh() {
        loadData();
        showAlert("Info", "Data refreshed successfully!");
    }

    @FXML
    private void handleViewToday() {
        String today = LocalDate.now().toString();
        List<Attendance> todayList = attendanceList.stream()
                .filter(a -> today.equals(a.getDate()))
                .collect(Collectors.toList());
        attendanceTable.setItems(FXCollections.observableArrayList(todayList));
        statusText.setText("Showing " + todayList.size() + " records for today");
    }

    private boolean validateForm() {
        if (workerComboBox.getValue() == null) {
            showAlert("Validation Error", "Please select a worker.");
            return false;
        }
        if (dateField.getText().trim().isEmpty()) {
            showAlert("Validation Error", "Please enter a date.");
            return false;
        }
        if (statusComboBox.getValue() == null) {
            showAlert("Validation Error", "Please select a status.");
            return false;
        }
        return true;
    }

    private void clearForm() {
        workerComboBox.setValue(null);
        dateField.clear();
        statusComboBox.setValue(null);
        notesField.clear();
        attendanceTable.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}