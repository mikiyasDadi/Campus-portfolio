package com.example.gobaweredamanagmentsystem.models;

public class Worker {
    private int id;
    private String name;
    private String gender;
    private String dateOfBirth;
    private String contact;
    private String address;
    private String hireDate;
    private String position;
    private String status;

    // Default constructor
    public Worker() {}

    // Constructor with all fields except id (for new workers)
    public Worker(String name, String gender, String dateOfBirth, String contact,
                  String address, String hireDate, String position, String status) {
        this.name = name;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.contact = contact;
        this.address = address;
        this.hireDate = hireDate;
        this.position = position;
        this.status = status;
    }

    // Constructor with all fields (for existing workers)
    public Worker(int id, String name, String gender, String dateOfBirth, String contact,
                  String address, String hireDate, String position, String status) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.contact = contact;
        this.address = address;
        this.hireDate = hireDate;
        this.position = position;
        this.status = status;
    }

    // Getters and setters for all fields
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(String dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getHireDate() { return hireDate; }
    public void setHireDate(String hireDate) { this.hireDate = hireDate; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}