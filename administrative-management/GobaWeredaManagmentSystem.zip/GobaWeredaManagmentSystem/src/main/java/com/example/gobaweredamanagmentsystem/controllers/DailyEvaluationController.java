package com.example.gobaweredamanagmentsystem.controllers;

import com.example.gobaweredamanagmentsystem.dao.DailyEvaluationDAO;
import com.example.gobaweredamanagmentsystem.dao.UserDAO;
import com.example.gobaweredamanagmentsystem.dao.UserPermissionsDAO;
import com.example.gobaweredamanagmentsystem.dao.WorkerDAO;
import com.example.gobaweredamanagmentsystem.models.DailyEvaluation;
import com.example.gobaweredamanagmentsystem.models.User;
import com.example.gobaweredamanagmentsystem.models.Worker;
import com.example.gobaweredamanagmentsystem.utils.ReportGenerator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class DailyEvaluationController {

    @FXML private TextField searchField;
    @FXML private TableView<DailyEvaluation> evaluationTable;
    @FXML private TableColumn<DailyEvaluation, Integer> idCol;
    @FXML private TableColumn<DailyEvaluation, String> workerNameCol;
    @FXML private TableColumn<DailyEvaluation, String> dateCol;
    @FXML private TableColumn<DailyEvaluation, String> evaluatorCol;
    @FXML private TableColumn<DailyEvaluation, Double> overallScoreCol;
    @FXML private TableColumn<DailyEvaluation, String> statusCol;
    @FXML private TableColumn<DailyEvaluation, String> lockedCol;

    @FXML private ComboBox<Worker> workerComboBox;
    @FXML private DatePicker evaluationDatePicker;
    @FXML private TextField evaluatorField;
    @FXML private Slider productivitySlider;
    @FXML private Slider qualitySlider;
    @FXML private Slider attendanceSlider;
    @FXML private Slider teamworkSlider;
    @FXML private TextField productivityScoreField;
    @FXML private TextField qualityScoreField;
    @FXML private TextField attendanceScoreField;
    @FXML private TextField teamworkScoreField;
    @FXML private TextField overallScoreField;
    @FXML private TextArea workCompletedArea;
    @FXML private TextArea challengesArea;
    @FXML private TextArea improvementsArea;
    @FXML private TextArea commentsArea;
    @FXML private ComboBox<String> statusComboBox;
    @FXML private Text statusText;

    @FXML private Button addButton;
    @FXML private Button editButton;
    @FXML private Button deleteButton;
    @FXML private Button lockButton;
    @FXML private Button exportButton;
    @FXML private Button clearButton;

    private ObservableList<DailyEvaluation> evaluationList = FXCollections.observableArrayList();
    private ObservableList<Worker> workerList = FXCollections.observableArrayList();
    private FilteredList<DailyEvaluation> filteredData;
    private SortedList<DailyEvaluation> sortedData;
    
    private User currentUser;
    private boolean canCreate = false;
    private boolean canUpdate = false;
    private boolean canDelete = false;
    private boolean canExport = false;

    @FXML
    public void initialize() {
        setupTableColumns();
        setupComboBoxes();
        setupSliders();
        loadData();
        setupSearchAndSort();
        setupTableSelection();
        setupAccessControl();
        updateButtonStates();
    }

    private void setupTableColumns() {
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        workerNameCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getWorkerName()));
        dateCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getEvaluationDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
        evaluatorCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getEvaluator()));
        overallScoreCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleDoubleProperty(cellData.getValue().getOverallScore()).asObject());
        statusCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));
        lockedCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().isLocked() ? "Locked" : "Unlocked"));
    }

    private void setupComboBoxes() {
        workerList.setAll(WorkerDAO.getAllWorkers());
        workerComboBox.setItems(workerList);
        workerComboBox.setCellFactory(param -> new ListCell<Worker>() {
            @Override
            protected void updateItem(Worker item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getName() + " (ID: " + item.getId() + ")");
                }
            }
        });
        workerComboBox.setButtonCell(workerComboBox.getCellFactory().call(null));

        statusComboBox.setItems(FXCollections.observableArrayList("Pending", "Completed", "Reviewed"));
        statusComboBox.setValue("Pending");
    }

    private void setupSliders() {
        // Configure sliders (0-5 scale)
        productivitySlider.setMin(0);
        productivitySlider.setMax(5);
        productivitySlider.setValue(3);
        productivitySlider.setShowTickLabels(true);
        productivitySlider.setShowTickMarks(true);
        productivitySlider.setMajorTickUnit(1);
        productivitySlider.setMinorTickCount(0);

        qualitySlider.setMin(0);
        qualitySlider.setMax(5);
        qualitySlider.setValue(3);
        qualitySlider.setShowTickLabels(true);
        qualitySlider.setShowTickMarks(true);
        qualitySlider.setMajorTickUnit(1);
        qualitySlider.setMinorTickCount(0);

        attendanceSlider.setMin(0);
        attendanceSlider.setMax(5);
        attendanceSlider.setValue(3);
        attendanceSlider.setShowTickLabels(true);
        attendanceSlider.setShowTickMarks(true);
        attendanceSlider.setMajorTickUnit(1);
        attendanceSlider.setMinorTickCount(0);

        teamworkSlider.setMin(0);
        teamworkSlider.setMax(5);
        teamworkSlider.setValue(3);
        teamworkSlider.setShowTickLabels(true);
        teamworkSlider.setShowTickMarks(true);
        teamworkSlider.setMajorTickUnit(1);
        teamworkSlider.setMinorTickCount(0);

        // Bind slider values to text fields
        productivitySlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            productivityScoreField.setText(String.format("%.1f", newVal.doubleValue()));
            calculateOverallScore();
        });

        qualitySlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            qualityScoreField.setText(String.format("%.1f", newVal.doubleValue()));
            calculateOverallScore();
        });

        attendanceSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            attendanceScoreField.setText(String.format("%.1f", newVal.doubleValue()));
            calculateOverallScore();
        });

        teamworkSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            teamworkScoreField.setText(String.format("%.1f", newVal.doubleValue()));
            calculateOverallScore();
        });

        // Set current date
        evaluationDatePicker.setValue(LocalDate.now());
    }

    private void calculateOverallScore() {
        double productivity = productivitySlider.getValue();
        double quality = qualitySlider.getValue();
        double attendance = attendanceSlider.getValue();
        double teamwork = teamworkSlider.getValue();
        
        double overall = (productivity + quality + attendance + teamwork) / 4.0;
        overallScoreField.setText(String.format("%.2f", overall));
    }

    private void loadData() {
        evaluationList.setAll(DailyEvaluationDAO.getAllDailyEvaluations());
        evaluationTable.setItems(evaluationList);
        statusText.setText("Loaded " + evaluationList.size() + " daily evaluation records");
    }

    private void setupSearchAndSort() {
        filteredData = new FilteredList<>(evaluationList, p -> true);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filteredData.setPredicate(eval -> {
                if (newVal == null || newVal.isEmpty()) return true;
                String filter = newVal.toLowerCase();
                return (eval.getWorkerName() != null && eval.getWorkerName().toLowerCase().contains(filter))
                        || (eval.getEvaluator() != null && eval.getEvaluator().toLowerCase().contains(filter))
                        || (eval.getStatus() != null && eval.getStatus().toLowerCase().contains(filter));
            });
        });

        sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(evaluationTable.comparatorProperty());
        evaluationTable.setItems(sortedData);
    }

    private void setupTableSelection() {
        evaluationTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                populateForm(newSel);
                updateButtonStates();
            }
        });
    }

    private void setupAccessControl() {
        // Get current user (you'll need to implement this based on your login system)
        // For now, we'll assume admin permissions
        canCreate = true;
        canUpdate = true;
        canDelete = true;
        canExport = true;
    }

    private void updateButtonStates() {
        DailyEvaluation selected = evaluationTable.getSelectionModel().getSelectedItem();
        
        addButton.setDisable(!canCreate);
        editButton.setDisable(!canUpdate || selected == null || selected.isLocked());
        deleteButton.setDisable(!canDelete || selected == null || selected.isLocked());
        lockButton.setDisable(selected == null || selected.isLocked());
        exportButton.setDisable(!canExport);
    }

    private void populateForm(DailyEvaluation evaluation) {
        // Find and select the worker
        for (Worker worker : workerList) {
            if (worker.getId() == evaluation.getWorkerId()) {
                workerComboBox.setValue(worker);
                break;
            }
        }
        
        evaluationDatePicker.setValue(evaluation.getEvaluationDate());
        evaluatorField.setText(evaluation.getEvaluator());
        productivitySlider.setValue(evaluation.getProductivityScore());
        qualitySlider.setValue(evaluation.getQualityScore());
        attendanceSlider.setValue(evaluation.getAttendanceScore());
        teamworkSlider.setValue(evaluation.getTeamworkScore());
        workCompletedArea.setText(evaluation.getWorkCompleted() != null ? evaluation.getWorkCompleted() : "");
        challengesArea.setText(evaluation.getChallenges() != null ? evaluation.getChallenges() : "");
        improvementsArea.setText(evaluation.getImprovements() != null ? evaluation.getImprovements() : "");
        commentsArea.setText(evaluation.getComments() != null ? evaluation.getComments() : "");
        statusComboBox.setValue(evaluation.getStatus());
    }

    @FXML
    private void handleAdd() {
        if (!canCreate) {
            showAlert("Access Denied", "You don't have permission to create evaluations.");
            return;
        }

        if (!validateForm()) return;

        DailyEvaluation evaluation = new DailyEvaluation(
                workerComboBox.getValue().getId(),
                evaluationDatePicker.getValue(),
                evaluatorField.getText().trim(),
                productivitySlider.getValue(),
                qualitySlider.getValue(),
                attendanceSlider.getValue(),
                teamworkSlider.getValue(),
                workCompletedArea.getText().trim(),
                challengesArea.getText().trim(),
                improvementsArea.getText().trim(),
                commentsArea.getText().trim()
        );

        if (DailyEvaluationDAO.addDailyEvaluation(evaluation)) {
            loadData();
            clearForm();
            showAlert("Success", "Daily evaluation added successfully!");
        } else {
            showAlert("Error", "Could not add daily evaluation.");
        }
    }

    @FXML
    private void handleEdit() {
        if (!canUpdate) {
            showAlert("Access Denied", "You don't have permission to edit evaluations.");
            return;
        }

        DailyEvaluation selected = evaluationTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a record to edit.");
            return;
        }

        if (selected.isLocked()) {
            showAlert("Record Locked", "This evaluation is locked and cannot be edited.");
            return;
        }

        if (!validateForm()) return;

        selected.setWorkerId(workerComboBox.getValue().getId());
        selected.setEvaluationDate(evaluationDatePicker.getValue());
        selected.setEvaluator(evaluatorField.getText().trim());
        selected.setProductivityScore(productivitySlider.getValue());
        selected.setQualityScore(qualitySlider.getValue());
        selected.setAttendanceScore(attendanceSlider.getValue());
        selected.setTeamworkScore(teamworkSlider.getValue());
        selected.setWorkCompleted(workCompletedArea.getText().trim());
        selected.setChallenges(challengesArea.getText().trim());
        selected.setImprovements(improvementsArea.getText().trim());
        selected.setComments(commentsArea.getText().trim());
        selected.setStatus(statusComboBox.getValue());

        if (DailyEvaluationDAO.updateDailyEvaluation(selected)) {
            loadData();
            clearForm();
            showAlert("Success", "Daily evaluation updated successfully!");
        } else {
            showAlert("Error", "Could not update daily evaluation.");
        }
    }

    @FXML
    private void handleDelete() {
        if (!canDelete) {
            showAlert("Access Denied", "You don't have permission to delete evaluations.");
            return;
        }

        DailyEvaluation selected = evaluationTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a record to delete.");
            return;
        }

        if (selected.isLocked()) {
            showAlert("Record Locked", "This evaluation is locked and cannot be deleted.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Delete");
        alert.setHeaderText("Delete Daily Evaluation");
        alert.setContentText("Are you sure you want to delete this evaluation record?");

        if (alert.showAndWait().orElse(null) == ButtonType.OK) {
            if (DailyEvaluationDAO.deleteDailyEvaluation(selected.getId())) {
                loadData();
                clearForm();
                showAlert("Success", "Daily evaluation deleted successfully!");
            } else {
                showAlert("Error", "Could not delete daily evaluation.");
            }
        }
    }

    @FXML
    private void handleLock() {
        DailyEvaluation selected = evaluationTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a record to lock.");
            return;
        }

        if (selected.isLocked()) {
            showAlert("Already Locked", "This evaluation is already locked.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Lock");
        alert.setHeaderText("Lock Daily Evaluation");
        alert.setContentText("Are you sure you want to lock this evaluation? It cannot be edited or deleted after locking.");

        if (alert.showAndWait().orElse(null) == ButtonType.OK) {
            if (DailyEvaluationDAO.lockEvaluation(selected.getId())) {
                loadData();
                updateButtonStates();
                showAlert("Success", "Daily evaluation locked successfully!");
            } else {
                showAlert("Error", "Could not lock daily evaluation.");
            }
        }
    }

    @FXML
    private void handleExport() {
        if (!canExport) {
            showAlert("Access Denied", "You don't have permission to export data.");
            return;
        }

        List<DailyEvaluation> evaluations = DailyEvaluationDAO.getAllDailyEvaluations();
        if (evaluations.isEmpty()) {
            showAlert("No Data", "No evaluations to export.");
            return;
        }

        String filePath = ReportGenerator.exportDailyEvaluationsToDesktop(evaluations, "All");
        if (filePath != null) {
            showAlert("Export Success", "Daily evaluations exported to: " + filePath);
        } else {
            showAlert("Export Error", "Failed to export daily evaluations.");
        }
    }

    @FXML
    private void handleClear() {
        clearForm();
    }

    private boolean validateForm() {
        if (workerComboBox.getValue() == null) {
            showAlert("Validation Error", "Please select a worker.");
            return false;
        }
        if (evaluationDatePicker.getValue() == null) {
            showAlert("Validation Error", "Please select an evaluation date.");
            return false;
        }
        if (evaluatorField.getText().trim().isEmpty()) {
            showAlert("Validation Error", "Please enter evaluator name.");
            return false;
        }
        return true;
    }

    private void clearForm() {
        workerComboBox.setValue(null);
        evaluationDatePicker.setValue(LocalDate.now());
        evaluatorField.clear();
        productivitySlider.setValue(3);
        qualitySlider.setValue(3);
        attendanceSlider.setValue(3);
        teamworkSlider.setValue(3);
        workCompletedArea.clear();
        challengesArea.clear();
        improvementsArea.clear();
        commentsArea.clear();
        statusComboBox.setValue("Pending");
        evaluationTable.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
} 