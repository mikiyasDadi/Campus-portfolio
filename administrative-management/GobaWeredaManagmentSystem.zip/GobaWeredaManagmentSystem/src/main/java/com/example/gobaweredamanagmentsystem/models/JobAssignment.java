package com.example.gobaweredamanagmentsystem.models;

public class JobAssignment {
    private int id;
    private int workerId;
    private int jobId;
    private String startDate;
    private String endDate;
    private String status; // Active, Completed, Terminated
    private String notes;

    // References to related objects (for display purposes)
    private String workerName;
    private String jobTitle;

    // Default constructor
    public JobAssignment() {}

    // Constructor for new assignments (without id)
    public JobAssignment(int workerId, int jobId, String startDate, String endDate, String status, String notes) {
        this.workerId = workerId;
        this.jobId = jobId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.notes = notes;
    }

    // Constructor with all fields
    public JobAssignment(int id, int workerId, int jobId, String startDate, String endDate, String status, String notes) {
        this.id = id;
        this.workerId = workerId;
        this.jobId = jobId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.notes = notes;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getWorkerId() { return workerId; }
    public void setWorkerId(int workerId) { this.workerId = workerId; }

    public int getJobId() { return jobId; }
    public void setJobId(int jobId) { this.jobId = jobId; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getWorkerName() { return workerName; }
    public void setWorkerName(String workerName) { this.workerName = workerName; }

    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }
}
