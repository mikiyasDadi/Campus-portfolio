package com.example.gobaweredamanagmentsystem.dao;

import com.example.gobaweredamanagmentsystem.utils.DatabaseHelper;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class UserPermissionsDAO {

    public static boolean addUserPermissions(int userId, String permissionType, 
                                           boolean canCreate, boolean canRead, boolean canUpdate, 
                                           boolean canDelete, boolean canExport, boolean canGenerateReports) {
        String sql = "INSERT OR REPLACE INTO user_permissions (user_id, permission_type, can_create, " +
                    "can_read, can_update, can_delete, can_export, can_generate_reports) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            pstmt.setString(2, permissionType);
            pstmt.setInt(3, canCreate ? 1 : 0);
            pstmt.setInt(4, canRead ? 1 : 0);
            pstmt.setInt(5, canUpdate ? 1 : 0);
            pstmt.setInt(6, canDelete ? 1 : 0);
            pstmt.setInt(7, canExport ? 1 : 0);
            pstmt.setInt(8, canGenerateReports ? 1 : 0);
            
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error adding user permissions: " + e.getMessage());
            return false;
        }
    }

    public static Map<String, Boolean> getUserPermissions(int userId, String permissionType) {
        Map<String, Boolean> permissions = new HashMap<>();
        String sql = "SELECT can_create, can_read, can_update, can_delete, can_export, can_generate_reports " +
                    "FROM user_permissions WHERE user_id=? AND permission_type=?";
        
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            pstmt.setString(2, permissionType);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                permissions.put("can_create", rs.getInt("can_create") == 1);
                permissions.put("can_read", rs.getInt("can_read") == 1);
                permissions.put("can_update", rs.getInt("can_update") == 1);
                permissions.put("can_delete", rs.getInt("can_delete") == 1);
                permissions.put("can_export", rs.getInt("can_export") == 1);
                permissions.put("can_generate_reports", rs.getInt("can_generate_reports") == 1);
            } else {
                // Default permissions (read-only)
                permissions.put("can_create", false);
                permissions.put("can_read", true);
                permissions.put("can_update", false);
                permissions.put("can_delete", false);
                permissions.put("can_export", false);
                permissions.put("can_generate_reports", false);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching user permissions: " + e.getMessage());
            // Default permissions on error
            permissions.put("can_create", false);
            permissions.put("can_read", true);
            permissions.put("can_update", false);
            permissions.put("can_delete", false);
            permissions.put("can_export", false);
            permissions.put("can_generate_reports", false);
        }
        return permissions;
    }

    public static boolean hasPermission(int userId, String permissionType, String action) {
        Map<String, Boolean> permissions = getUserPermissions(userId, permissionType);
        return permissions.getOrDefault(action, false);
    }

    public static boolean canCreate(int userId, String permissionType) {
        return hasPermission(userId, permissionType, "can_create");
    }

    public static boolean canRead(int userId, String permissionType) {
        return hasPermission(userId, permissionType, "can_read");
    }

    public static boolean canUpdate(int userId, String permissionType) {
        return hasPermission(userId, permissionType, "can_update");
    }

    public static boolean canDelete(int userId, String permissionType) {
        return hasPermission(userId, permissionType, "can_delete");
    }

    public static boolean canExport(int userId, String permissionType) {
        return hasPermission(userId, permissionType, "can_export");
    }

    public static boolean canGenerateReports(int userId, String permissionType) {
        return hasPermission(userId, permissionType, "can_generate_reports");
    }

    public static boolean setupDefaultPermissions() {
        try {
            // Get all users
            String userSql = "SELECT id, role FROM user";
            try (Connection conn = DatabaseHelper.connect();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(userSql)) {
                
                while (rs.next()) {
                    int userId = rs.getInt("id");
                    String role = rs.getString("role");
                    
                    // Set permissions based on role with retry logic
                    if ("admin".equalsIgnoreCase(role)) {
                        // Admin has all permissions
                        retryAddPermissions(userId, "evaluation", true, true, true, true, true, true);
                        retryAddPermissions(userId, "report", true, true, true, true, true, true);
                        retryAddPermissions(userId, "worker", true, true, true, true, true, true);
                        retryAddPermissions(userId, "job", true, true, true, true, true, true);
                        retryAddPermissions(userId, "attendance", true, true, true, true, true, true);
                    } else if ("manager".equalsIgnoreCase(role)) {
                        // Manager can create, read, update, export, and generate reports
                        retryAddPermissions(userId, "evaluation", true, true, true, false, true, true);
                        retryAddPermissions(userId, "report", true, true, true, false, true, true);
                        retryAddPermissions(userId, "worker", true, true, true, false, true, true);
                        retryAddPermissions(userId, "job", true, true, true, false, true, true);
                        retryAddPermissions(userId, "attendance", true, true, true, false, true, true);
                    } else {
                        // Regular user can only read and export
                        retryAddPermissions(userId, "evaluation", false, true, false, false, true, false);
                        retryAddPermissions(userId, "report", false, true, false, false, true, false);
                        retryAddPermissions(userId, "worker", false, true, false, false, true, false);
                        retryAddPermissions(userId, "job", false, true, false, false, true, false);
                        retryAddPermissions(userId, "attendance", false, true, false, false, true, false);
                    }
                }
            }
            return true;
        } catch (SQLException e) {
            System.out.println("Error setting up default permissions: " + e.getMessage());
            return false;
        }
    }
    
    private static void retryAddPermissions(int userId, String permissionType, 
                                          boolean canCreate, boolean canRead, boolean canUpdate, 
                                          boolean canDelete, boolean canExport, boolean canGenerateReports) {
        int maxRetries = 3;
        int retryCount = 0;
        
        while (retryCount < maxRetries) {
            try {
                // Add a small delay to avoid database locking
                Thread.sleep(50);
                addUserPermissions(userId, permissionType, canCreate, canRead, canUpdate, canDelete, canExport, canGenerateReports);
                return; // Success, exit the retry loop
            } catch (Exception e) {
                retryCount++;
                if (retryCount >= maxRetries) {
                    System.out.println("Failed to add permissions for user " + userId + " after " + maxRetries + " retries: " + e.getMessage());
                } else {
                    try {
                        Thread.sleep(100 * retryCount); // Exponential backoff
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        }
    }

    public static boolean updateUserPermissions(int userId, String permissionType, 
                                              boolean canCreate, boolean canRead, boolean canUpdate, 
                                              boolean canDelete, boolean canExport, boolean canGenerateReports) {
        return addUserPermissions(userId, permissionType, canCreate, canRead, canUpdate, canDelete, canExport, canGenerateReports);
    }

    public static boolean deleteUserPermissions(int userId) {
        String sql = "DELETE FROM user_permissions WHERE user_id=?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error deleting user permissions: " + e.getMessage());
            return false;
        }
    }
} 