package com.example.gobaweredamanagmentsystem;

import com.example.gobaweredamanagmentsystem.dao.UserDAO;
import com.example.gobaweredamanagmentsystem.models.User;
import com.example.gobaweredamanagmentsystem.utils.DatabaseHelper;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Objects;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Ensure the tables exist
        DatabaseHelper.createWorkerTable();
        DatabaseHelper.createJobTable();
        DatabaseHelper.createJobAssignmentTable();
        DatabaseHelper.createAttendanceTable();
        DatabaseHelper.createEvaluationTable();
        DatabaseHelper.createDailyEvaluationTable();
        DatabaseHelper.createReportTable();
        DatabaseHelper.createUserTable();
        DatabaseHelper.createUserPermissionsTable();

        if (UserDAO.getUserByUsername("admin") == null) {
            UserDAO.addUser(new User("admin", "admin", "admin"));
        }

        // Setup default permissions
        try {
            com.example.gobaweredamanagmentsystem.dao.UserPermissionsDAO.setupDefaultPermissions();
        } catch (Exception e) {
            System.out.println("Warning: Could not setup default permissions: " + e.getMessage());
        }

        // Load the login FXML

            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/gobaweredamanagmentsystem/login.fxml")));
            primaryStage.setTitle("Login - Goba Wereda Management System");
            primaryStage.setScene(new Scene(root, 900, 600)); // Set a large default size
            primaryStage.setMaximized(true); // Make it full screen
            primaryStage.show();
        }


    public static void main(String[] args) {
        Application.launch(args);
    }
}