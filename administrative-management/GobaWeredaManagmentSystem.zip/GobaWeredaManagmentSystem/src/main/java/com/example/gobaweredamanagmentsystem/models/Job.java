package com.example.gobaweredamanagmentsystem.models;

public class Job {
    private int id;
    private String title;
    private String description;
    private String department;
    private String requirements;
    private double salary;
    private String status; // Active, Inactive, etc.

    // Default constructor
    public Job() {}

    // Constructor for new jobs (without id)
    public Job(String title, String description, String department,
               String requirements, double salary, String status) {
        this.title = title;
        this.description = description;
        this.department = department;
        this.requirements = requirements;
        this.salary = salary;
        this.status = status;
    }

    // Constructor with all fields
    public Job(int id, String title, String description, String department,
               String requirements, double salary, String status) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.department = department;
        this.requirements = requirements;
        this.salary = salary;
        this.status = status;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getRequirements() { return requirements; }
    public void setRequirements(String requirements) { this.requirements = requirements; }

    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}