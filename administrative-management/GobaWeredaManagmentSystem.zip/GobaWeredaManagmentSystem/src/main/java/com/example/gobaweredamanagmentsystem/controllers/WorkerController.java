package com.example.gobaweredamanagmentsystem.controllers;

import com.example.gobaweredamanagmentsystem.dao.WorkerDAO;
import com.example.gobaweredamanagmentsystem.models.Worker;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class WorkerController {

    @FXML private TextField searchField;
    @FXML private TableView<Worker> workerTable;
    @FXML private TableColumn<Worker, Integer> idCol;
    @FXML private TableColumn<Worker, String> nameCol;
    @FXML private TableColumn<Worker, String> genderCol;
    @FXML private TableColumn<Worker, String> dobCol;
    @FXML private TableColumn<Worker, String> contactCol;
    @FXML private TableColumn<Worker, String> addressCol;
    @FXML private TableColumn<Worker, String> hireDateCol;
    @FXML private TableColumn<Worker, String> positionCol;
    @FXML private TableColumn<Worker, String> statusCol;

    @FXML private TextField nameField;
    @FXML private TextField genderField;
    @FXML private TextField dobField;
    @FXML private TextField contactField;
    @FXML private TextField addressField;
    @FXML private TextField hireDateField;
    @FXML private TextField positionField;
    @FXML private TextField statusField;

    private ObservableList<Worker> workerList = FXCollections.observableArrayList();
    private FilteredList<Worker> filteredData;
    private SortedList<Worker> sortedData;

    @FXML
    public void initialize() {
        // Set up table columns
        idCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        nameCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getName()));
        genderCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getGender()));
        dobCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDateOfBirth()));
        contactCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getContact()));
        addressCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getAddress()));
        hireDateCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getHireDate()));
        positionCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getPosition()));
        statusCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));

        // Load data
        loadWorkers();

        // Set up filtering and sorting
        filteredData = new FilteredList<>(workerList, p -> true);

        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(worker -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();
                return worker.getName().toLowerCase().contains(lowerCaseFilter)
                        || worker.getContact().toLowerCase().contains(lowerCaseFilter)
                        || worker.getPosition().toLowerCase().contains(lowerCaseFilter)
                        || worker.getStatus().toLowerCase().contains(lowerCaseFilter);
            });
        });

        sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(workerTable.comparatorProperty());
        workerTable.setItems(sortedData);

        // When a row is selected, fill the fields
        workerTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                nameField.setText(newSel.getName());
                genderField.setText(newSel.getGender());
                dobField.setText(newSel.getDateOfBirth());
                contactField.setText(newSel.getContact());
                addressField.setText(newSel.getAddress());
                hireDateField.setText(newSel.getHireDate());
                positionField.setText(newSel.getPosition());
                statusField.setText(newSel.getStatus());
            }
        });
    }

    private void loadWorkers() {
        workerList.setAll(WorkerDAO.getAllWorkers());
        // Do NOT set workerTable.setItems(workerList) here!
    }

    @FXML
    private void handleAdd() {
        Worker worker = new Worker(
                nameField.getText(),
                genderField.getText(),
                dobField.getText(),
                contactField.getText(),
                addressField.getText(),
                hireDateField.getText(),
                positionField.getText(),
                statusField.getText()
        );
        if (WorkerDAO.addWorker(worker)) {
            loadWorkers();
            clearFields();
        } else {
            showAlert("Error", "Could not add worker.");
        }
    }

    @FXML
    private void handleEdit() {
        Worker selected = workerTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a worker to edit.");
            return;
        }
        selected.setName(nameField.getText());
        selected.setGender(genderField.getText());
        selected.setDateOfBirth(dobField.getText());
        selected.setContact(contactField.getText());
        selected.setAddress(addressField.getText());
        selected.setHireDate(hireDateField.getText());
        selected.setPosition(positionField.getText());
        selected.setStatus(statusField.getText());

        if (WorkerDAO.updateWorker(selected)) {
            loadWorkers();
            clearFields();
        } else {
            showAlert("Error", "Could not update worker.");
        }
    }

    @FXML
    private void handleDelete() {
        Worker selected = workerTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No selection", "Please select a worker to delete.");
            return;
        }
        if (WorkerDAO.deleteWorker(selected.getId())) {
            loadWorkers();
            clearFields();
        } else {
            showAlert("Error", "Could not delete worker.");
        }
    }

    private void clearFields() {
        nameField.clear();
        genderField.clear();
        dobField.clear();
        contactField.clear();
        addressField.clear();
        hireDateField.clear();
        positionField.clear();
        statusField.clear();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}